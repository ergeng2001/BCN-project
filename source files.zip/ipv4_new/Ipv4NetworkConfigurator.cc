//
// Copyright (C) 2012 OpenSim Ltd.
//
// SPDX-License-Identifier: LGPL-3.0-or-later
//


#include "models/inet/networklayer/configurator/ipv4/Ipv4NetworkConfigurator.h"

#include <set>

#include "models/inet/common/INETUtils.h"
#include "models/inet/common/ModuleAccess.h"
#include "models/inet/common/XMLUtils.h"
#include "models/inet/common/stlutils.h"
#include "models/inet/networklayer/common/L3AddressResolver.h"
#include "models/inet/networklayer/common/NetworkInterface.h"
#include "models/inet/networklayer/contract/IInterfaceTable.h"
#include "models/inet/networklayer/ipv4/IIpv4RoutingTable.h"
#include "platform/scheduler/glex_scheduler/glexparsimscheduler.h"
#include <platform/parsim/psmcommbuffer.h>
#include "/home/mpi_share/env/omnetpp/omnetpp-6.0/src/sim/parsim/cnullmessageprot.h"

namespace inet {

Define_Module(Ipv4NetworkConfigurator);

#define ADDRLEN_BITS    32

Ipv4NetworkConfigurator::InterfaceInfo::InterfaceInfo(Node *node, LinkInfo *linkInfo, NetworkInterface *networkInterface) :
    L3NetworkConfiguratorBase::InterfaceInfo(node, linkInfo, networkInterface),
    address(0),
    addressSpecifiedBits(0),
    netmask(0),
    netmaskSpecifiedBits(0)
{
}

int Ipv4NetworkConfigurator::RoutingTableInfo::addRouteInfo(RouteInfo *routeInfo)
{
    auto it = upper_bound(routeInfos.begin(), routeInfos.end(), routeInfo, routeInfoLessThan);
    int index = it - routeInfos.begin();
    routeInfos.insert(it, routeInfo);
    return index;
}

Ipv4NetworkConfigurator::RouteInfo *Ipv4NetworkConfigurator::RoutingTableInfo::findBestMatchingRouteInfo(const std::vector<RouteInfo *>& routeInfos, const uint32_t destination, int begin, int end)
{
    for (int index = begin; index < end; index++) {
        RouteInfo *routeInfo = routeInfos.at(index);
        if (routeInfo->enabled && !((destination ^ routeInfo->destination) & routeInfo->netmask))
            return const_cast<RouteInfo *>(routeInfo);
    }
    return nullptr;
}

void Ipv4NetworkConfigurator::recvPsmNetConfigData() {
	string comm_class = getSimulation()->getEnvir()->getConfig()->getConfigValue("parsim-synchronization-class");
	if(comm_class=="cNullMessageProtocol"){
		psmNetConfigData *pncd;
		int receivedTag, srcPid, numOfNonLocalNodes;
		cNullMessageProtocol *scheduler = dynamic_cast<cNullMessageProtocol*>(getSimulation()->getScheduler());
		assert(scheduler);
		cMPICommunications *pcom = new cMPICommunications();
		numOfNonLocalNodes = getNumOfNonLocalNodes();
		srcPid = MPI_ANY_SOURCE;
		int pid = getSimulation()->getEnvir()->getParsimProcId();
		for (int idx = 0; idx < numOfNonLocalNodes; idx++) {
			cCommBuffer *buffer = pcom->createCommBuffer();
			pcom->receiveBlocking(pid, buffer, receivedTag, srcPid);
			pncd = dynamic_cast<psmNetConfigData*>(buffer->unpackObject());
			assert(pncd);
			// std::cout << "####" << this->getFullPath() << ",idx:" << idx << ", pid:" << pid << ",nodeModuleId:" << pncd->getNodeModuleId()
			// 		<< ",getNumInterfaces:" <<  pncd->getInterfaceTable()->getNumInterfaces()
			// 		<< ",mtu:" << pncd->getInterfaceTable()->getInterface(1)->getMtu()
			// 		<< ",haveRoutingTable:" << pncd->getHaveRoutingTable()
			// 		<< ", Ipv4NetworkConfigurator recv PsmNetConfigData" <<std::endl;
			assert(nodeModuleId2psmNetCfgData.count(pncd->getNodeModuleId()) == 0);
			nodeModuleId2psmNetCfgData[pncd->getNodeModuleId()] = pncd;//std::cout<<"count = "<<nodeModuleId2psmNetCfgData.count(pncd->getNodeModuleId())<<", parsimid = "<<getSimulation()->getEnvir()->getParsimProcId()<<std::endl;
			pncd->getInterfaceTable()->setHostModule(getSimulation()->getModule(pncd->getNodeModuleId()));
			pcom->recycleCommBuffer(buffer);
		}
		
	}else{
		psmNetConfigData *pncd;
		int receivedTag, srcPid, numOfNonLocalNodes;
		GlexParsimScheduler *scheduler = dynamic_cast<GlexParsimScheduler*>(getSimulation()->getScheduler());
		assert(scheduler);
		PSMCommunications *pcom = scheduler->getComm();
		numOfNonLocalNodes = getNumOfNonLocalNodes();
		srcPid = MPI_ANY_SOURCE;
		int pid = getSimulation()->getEnvir()->getParsimProcId();
		for (int idx = 0; idx < numOfNonLocalNodes; idx++) {//cout <<this->getFullPath()<<": numNonLocalNodes = "<<numOfNonLocalNodes<<", idx = "<<idx<<endl;
			cCommBuffer *buffer = pcom->createCommBuffer();
			pcom->receiveBlocking(pid, buffer, receivedTag, srcPid);
			pncd = dynamic_cast<psmNetConfigData*>(buffer->unpackObject());
			assert(pncd);
			// std::cout << "####" << this->getFullPath() << ",idx:" << idx << ", pid:" << pid << ",nodeModuleId:" << pncd->getNodeModuleId()
			// 		<< ",getNumInterfaces:" <<  pncd->getInterfaceTable()->getNumInterfaces()
			// 		<< ",mtu:" << pncd->getInterfaceTable()->getInterface(1)->getMtu()
			// 		<< ",haveRoutingTable:" << pncd->getHaveRoutingTable()
					// << ", Ipv4NetworkConfigurator recv PsmNetConfigData"<<std::endl ;
			assert(nodeModuleId2psmNetCfgData.count(pncd->getNodeModuleId()) == 0);
			nodeModuleId2psmNetCfgData[pncd->getNodeModuleId()] = pncd;//std::cout<<"count = "<<nodeModuleId2psmNetCfgData.count(pncd->getNodeModuleId())<<", parsimid = "<<getSimulation()->getEnvir()->getParsimProcId()<<std::endl;
			pncd->getInterfaceTable()->setHostModule(getSimulation()->getModule(pncd->getNodeModuleId()));
			pcom->recycleCommBuffer(buffer);
		}
	}
    std::cout << "$$$$" << this->getFullPath() << ": recvPsmNetConfigData completed in " << comm_class << std::endl;
}

void Ipv4NetworkConfigurator::sendAddrData() {
	string comm_class = getSimulation()->getEnvir()->getConfig()->getConfigValue("parsim-synchronization-class");
	if(comm_class=="cNullMessageProtocol"){

	}else{
		GlexParsimScheduler *scheduler = dynamic_cast<GlexParsimScheduler*>(getSimulation()->getScheduler());
		assert(scheduler);
		int pid = getSimulation()->getEnvir()->getParsimProcId();//cout<<this->getFullPath()<<": pid = "<<pid<<endl;
		int num_lps = this->getSystemModule()->par("num_lps").intValue();
		PSMCommunications *pcom = scheduler->getComm();
        psmAddrData *pad = new psmAddrData();
        // std::cout << "#####"<<  this->getFullPath() << ": cur_lp_node_Num = " << cur_lp_nodeId[pid].size() <<std::endl;
        for(auto elem:topology.interfaceInfos){
            if(find(cur_lp_nodeId[pid].begin(),cur_lp_nodeId[pid].end(),elem.first.nodeId)!=cur_lp_nodeId[pid].end()){
                psmAddrDataStruct *pads = new psmAddrDataStruct(elem.first.nodeId, elem.first.modId, static_cast<InterfaceInfo *>(elem.second)->getAddress().getInt(),
                static_cast<InterfaceInfo *>(elem.second)->getNetmask().getInt());
                // pad->setData(pad->getArraySize(),pads);
                // pad->setArraySize(pad->getArraySize()+1);
                for (int destPid = 0; destPid < num_lps; ++destPid) {
                    if (pid == destPid)
                        continue;
                        // std::stringstream ss;
                        // ss<<"#####"<<  this->getFullPath() << "send psmAddrData to Porc " << destPid << " : nodeid = " << elem.first.nodeId 
                        // << ", addr = " << static_cast<InterfaceInfo *>(elem.second)->getAddress() << ", netmask = "<<static_cast<InterfaceInfo *>(elem.second)->getNetmask();
                        // std::cout << ss.str()<<std::endl<<std::flush;
                    omnetpp::cCommBuffer *buffer = pcom->createCommBuffer();
                    buffer->packObject(pads);
                    pcom->send(buffer, destPid, destPid);
                    pcom->recycleCommBuffer(buffer);
                }
                // std::cout<<"set nodeData, nodeid = "<<elem.first.nodeId<<", modid = "<<elem.first.modId<<", addr = "<<static_cast<InterfaceInfo *>(elem.second)->getAddress().getInt()
                // <<", netmask = "<<static_cast<InterfaceInfo *>(elem.second)->getNetmask().getInt()<<std::endl;
                delete pads;
            } 
        }
        // for (int destPid = 0; destPid < num_lps; ++destPid) {
        //     if (pid == destPid)
        //         continue;
        //             std::cout << "#####"<<  this->getFullPath() << ": nodedataNum = " << pad->getArraySize()
        //             // << ",getNumInterfaces:" << this->getNumInterfaces()
        //             << ",send psmAddrData destPid:" << destPid << std::endl;
        //     omnetpp::cCommBuffer *buffer = pcom->createCommBuffer();
        //     buffer->packObject(pad);
        //     pcom->send(buffer, destPid, destPid);
        //     pcom->recycleCommBuffer(buffer);
        //     delete pad;
        // }
	}
    std::cout << "$$$$" << this->getFullPath() << ": sendAddrData completed in " << comm_class << std::endl;
}

void Ipv4NetworkConfigurator::recvAddrData() {
	string comm_class = getSimulation()->getEnvir()->getConfig()->getConfigValue("parsim-synchronization-class");
	if(comm_class=="cNullMessageProtocol"){

	}else{
		psmAddrData *pad;
		int receivedTag, srcPid, numOfNonLocalEths;
		GlexParsimScheduler *scheduler = dynamic_cast<GlexParsimScheduler*>(getSimulation()->getScheduler());
		assert(scheduler);
		PSMCommunications *pcom = scheduler->getComm();
        numOfNonLocalEths = getNumOfNonLocalEths();//std::cout<<"numOfNonLocalEths = "<<numOfNonLocalEths<<std::endl;
		srcPid = MPI_ANY_SOURCE;
		int pid = getSimulation()->getEnvir()->getParsimProcId();
        for (int idx = 0; idx < numOfNonLocalEths; idx++) {
            cCommBuffer *buffer = pcom->createCommBuffer();
            pcom->receiveBlocking(pid, buffer, receivedTag, srcPid);
            psmAddrDataStruct *pads = dynamic_cast<psmAddrDataStruct*>(buffer->unpackObject());
            nmIdPair pkey = {pads->getNodeId(), pads->getModId()}; 
            static_cast<InterfaceInfo *>(topology.interfaceInfos[pkey])->address=pads->getAddr();
            static_cast<InterfaceInfo *>(topology.interfaceInfos[pkey])->netmask=pads->getNetmask();
            // std::stringstream ss;
            // ss << "####" << this->getFullPath() << "recv PsmAddrData from Proc " << srcPid<< ", nodeid = "<< pads->getNodeId()
            // << ", addr = " << Ipv4Address(pads->getAddr()) << ", netmask = " << Ipv4Address(pads->getNetmask());
            // std::cout <<ss.str() <<std::endl<<std::flush;
            pcom->recycleCommBuffer(buffer);
        }
        // cCommBuffer *buffer = pcom->createCommBuffer();std::cout<<"####"<< this->getFullPath()<<" prepare receive"<<std::endl;
        // pcom->receiveBlocking(pid, buffer, receivedTag, srcPid);
        // pad = dynamic_cast<psmAddrData*>(buffer->unpackObject());
        // for(int i=0; i<pad->getArraySize(); i++){
        //     psmAddrDataStruct pads = pad->getData(i);
        //     nmIdPair pkey = {pads.getNodeId(), pads.getModId()}; 
        //     static_cast<InterfaceInfo *>(topology.interfaceInfos[pkey])->address=pads.getAddr();
        //     static_cast<InterfaceInfo *>(topology.interfaceInfos[pkey])->netmask=pads.getNetmask();
        //     std::cout << "####" << this->getFullPath() << ", pid:" << pid <<", nodeid = " << pads.getNodeId() << ", modid = "<< pads.getModId()
        //     << ", addr = " << pads.getAddr() << ", netmask = " << pads.getNetmask()
        // // // 		<< ",getNumInterfaces:" <<  pad->getInterfaceTable()->getNumInterfaces()
        // // // 		<< ",mtu:" << pad->getInterfaceTable()->getInterface(1)->getMtu()
        // // // 		<< ",haveRoutingTable:" << pad->getHaveRoutingTable()
        // 		<< ", Ipv4NetworkConfigurator recv PsmAddrData"<<std::endl;
        // }
        // pcom->recycleCommBuffer(buffer);
	}
    std::cout << "$$$$" << this->getFullPath() << ": recvAddrData completed in " << comm_class << std::endl;
}

void Ipv4NetworkConfigurator::initialize(int stage)
{
	EV_INFO<<"Ipv4NetworkConfigurator::initialize(), stage = "<<stage<<endl;
    L3NetworkConfiguratorBase::initialize(stage);
    if (stage == INITSTAGE_LOCAL) {EV_INFO<<"Ipv4NetworkConfigurator::initialize(), INITSTAGE_LOCAL"<<endl;
        assignAddressesParameter = par("assignAddresses");
        assignUniqueAddresses = par("assignUniqueAddresses");
        assignDisjunctSubnetAddressesParameter = par("assignDisjunctSubnetAddresses");
        addStaticRoutesParameter = par("addStaticRoutes");
        addSubnetRoutesParameter = par("addSubnetRoutes");
        addDefaultRoutesParameter = par("addDefaultRoutes");
        addDirectRoutesParameter = par("addDirectRoutes");
        optimizeRoutesParameter = par("optimizeRoutes");
        ecmp = par("ecmp");
    }
    else if (stage == INITSTAGE_NETWORK_CONFIGURATION) { //12
        // cout<<"stage INISTAGE_NETWORK_CONFIGURATION = "<<stage<<endl;

		enParsim = getSimulation()->getEnvir()->getParsimNumPartitions() > 0;
		if (enParsim) {
            omnetpp::cScheduler * Scheduler = getSimulation()->getScheduler();
            cur_lp_nodeId.resize(getSimulation()->getEnvir()->getParsimNumPartitions());
            int id = getSimulation()->getEnvir()->getParsimProcId();
            for (int modId = 0; modId < Scheduler->getSimulation()->getLastComponentId(); modId++) {
                omnetpp::cModule *mod = Scheduler->getSimulation()->getModule(modId);
                if (mod && !mod->isPlaceholder() && ((string(mod->getModuleType()->getName()).find("HiSwitch") != string::npos) || (string(mod->getModuleType()->getName()).find("HiHost") != string::npos))) 
                    cur_lp_nodeId[id].push_back(modId);
            }
            // cout <<"cur_lp "<<id<<" consist of: ";
            // for (auto it = 0; it != cur_lp_nodeId[id].size(); it++){
            //     cout <<cur_lp_nodeId[id][it] << " ";
            // }cout <<endl;
			recvPsmNetConfigData();
		}
        ensureConfigurationComputed(topology);
        // for(auto elem : topology.interfaceInfos){
            // std::cout<<"interface "<<elem.second->getFullPath()<<", addr = "<<static_cast<InterfaceInfo *>(elem.second)->getAddress()<<std::endl;
        // }
        // if(enParsim)
            
        // if(getSimulation()->getEnvir()->getParsimProcId()==0)
        //     recvAddrData();
    }
    else if (stage == 13){
        // if(enParsim)
            
    }
    else if (stage == INITSTAGE_LAST)
        dumpConfiguration();
}

void Ipv4NetworkConfigurator::computeConfiguration()
{//std::cout<<this->getFullPath()<<" computeConfiguration started.\n"<<std::endl;
    EV_INFO << "Computing static network configuration (addresses and routes).\n";
    long initializeStartTime = clock();
    topology.clear();
    // extract topology into the Topology object, then fill in a LinkInfo[] vector
    long extracToplogyStartTime = clock();
    TIME(extractTopology(topology));//cout << this->getFullPath() << " Time spent in extractTopology: " << (static_cast<double>(clock() - extracToplogyStartTime) / CLOCKS_PER_SEC) << "s" << endl;

    // read the configuration from XML; it will serve as input for address assignment
    // 给((topology.linkInfos)[*]->interfaceInfos)[*]赋值， 通过遍历linkInfos，
    // 并给每个interfaceInfos分配了IP和mask，假如xml配置的ip为10.0.0.x给interface分配的为10.0.0.0，mask也同样，因此需要进一步分配IP和mask+
    long readInterfaceConfigurationStartTime = clock();
    TIME(readInterfaceConfiguration(topology));//cout << this->getFullPath() << "Time spent in readInterfaceConfiguration: " << (static_cast<double>(clock() - readInterfaceConfigurationStartTime) / CLOCKS_PER_SEC) << "s" << endl;
    // assign addresses to Ipv4 nodes
    if (assignAddressesParameter){
        long assignAddressesStartTime = clock();
        TIME(assignAddresses(topology));cout << this->getFullPath() << "Time spent in assignAddresses: " << (static_cast<double>(clock() - assignAddressesStartTime) / CLOCKS_PER_SEC) << "s" << endl;
    }

    long exchangeAddressesStartTime = clock();
    sendAddrData();
    recvAddrData();
    cout << this->getFullPath() << "Time spent in exchangeAddresses: " << (static_cast<double>(clock() - exchangeAddressesStartTime) / CLOCKS_PER_SEC) << "s" << endl;
    
    long readMulticastGroupConfigurationStartTime = clock();
    // read and configure multicast groups from the XML configuration
    TIME(readMulticastGroupConfiguration(topology));//cout << this->getFullPath() << "Time spent in readMulticastGroupConfiguration: " << (static_cast<double>(clock() - readMulticastGroupConfigurationStartTime) / CLOCKS_PER_SEC) << "s" << endl;
    // read and configure manual routes from the XML configuration
    readManualRouteConfiguration(topology);//std::cout<<this->getFullPath()<<" readManualRouteConfiguration finished.\n"<<std::endl;
    // read and configure manual multicast routes from the XML configuration
    readManualMulticastRouteConfiguration(topology);//std::cout<<this->getFullPath()<<" readManualMulticastRouteConfiguration finished.\n"<<std::endl;
    // calculate shortest paths, and add corresponding static routes
    if (addStaticRoutesParameter) {//std::cout<<this->getFullPath()<<" addStaticRoutesParameter started.\n"<<std::endl;
        cXMLElementList autorouteElements = configuration->getChildrenByTagName("autoroute");
        if (autorouteElements.size() == 0) {
        	EV_INFO<<"Ipv4NetworkConfigurator.cc: line "<<__LINE__<<endl;
            cXMLElement defaultAutorouteElement("autoroute", "", nullptr);
            long addStaticRoutesStartTime = clock();
            TIME(addStaticRoutes(topology, &defaultAutorouteElement));cout << this->getFullPath() << "Time spent in addStaticRoutes: " << (static_cast<double>(clock() - addStaticRoutesStartTime) / CLOCKS_PER_SEC) << "s" << endl;
        }
        else {EV_INFO<<"Ipv4NetworkConfigurator.cc: line "<<__LINE__<<endl;
        	for (auto& autorouteElement : autorouteElements)
                TIME(addStaticRoutes(topology, autorouteElement));
        }
    }//std::cout<<this->getFullPath()<<" computeConfiguration finished.\n"<<std::endl;
    cout << "Time spent in computeConfiguration: " << (static_cast<double>(clock() - initializeStartTime) / CLOCKS_PER_SEC) << "s" << endl;
    printElapsedTime("computeConfiguration", initializeStartTime);

}

void Ipv4NetworkConfigurator::ensureConfigurationComputed(Topology& topology)
{EV_INFO<<"Ipv4NetworkConfigurator::ensureConfigurationComputed(Topology& topology), NUMNODES = "<<topology.getNumNodes()<<endl;
    if (topology.getNumNodes() == 0)
        computeConfiguration();
}

void Ipv4NetworkConfigurator::dumpConfiguration()
{EV_INFO<<"Ipv4NetworkConfigurator::dumpConfiguration()"<<endl;
    // print topology to module output
//    if (par("dumpTopology"))
//        TIME(dumpTopology(topology));
//    // print links to module output
//    if (par("dumpLinks"))
//        TIME(dumpLinks(topology));
//    // print unicast and multicast addresses and other interface data to module output
//    if (par("dumpAddresses"))
//        TIME(dumpAddresses(topology));
//    // print routes to module output
//    if (par("dumpRoutes"))
//        TIME(dumpRoutes(topology));


    if (par("dumpTopology")) {
		for (int i = 0; i < topology.getNumNodes(); i++) {
			Node *node = (Node*) topology.getNode(i);
			std::cout  << "=== dumpTopology Node (network_id: " << node->getNetworkId() << ") "
					<< node->module->getFullPath() << ",id:" << node->module->getId() << std::endl;
			for (int j = 0; j < node->getNumOutLinks(); j++) {
				Topology::Link *linkOut = node->getLinkOut(j);
				ASSERT(linkOut->getLinkOutLocalNode() == node);
				Node *remoteNode = (Node*) linkOut->getLinkOutRemoteNode();
				std::cout << "     -> " << remoteNode->module->getFullPath() << std::endl;
			}
			for (int j = 0; j < node->getNumInLinks(); j++) {
				Topology::Link *linkIn = node->getLinkIn(j);
				ASSERT(linkIn->getLinkInLocalNode() == node);
				Node *remoteNode = (Node*) linkIn->getLinkInRemoteNode();
				std::cout << "     <- " << remoteNode->module->getFullPath() << std::endl;
			}
		}
	}
//    // print links to module output
//    if (par("dumpLinks")) {
//		for (size_t i = 0; i < topology.linkInfos.size(); i++) {
//			std::cout << "=== dumpLinks Link " << i << std::endl;
//			LinkInfo *linkInfo = topology.linkInfos[i];
//			for (auto &element : linkInfo->interfaceInfos) {
//				InterfaceInfo *interfaceInfo = static_cast<InterfaceInfo*>(element);
//				std::cout << "     " << interfaceInfo->networkInterface->getInterfaceFullPath() << std::endl;
//			}
//		}
//    }
    // print unicast and multicast addresses and other interface data to module output
    if (par("dumpAddresses")) {
		for (size_t i = 0; i < topology.linkInfos.size(); i++) {
			std::cout << "=== dumpAddresses Link " << i << std::endl;
			LinkInfo *linkInfo = topology.linkInfos[i];
			for (auto &interfaceInfo : linkInfo->interfaceInfos) {
				NetworkInterface *networkInterface = interfaceInfo->networkInterface;
				cModule *host = interfaceInfo->node->module;
				std::cout << "    " << host->getFullName() << " / " << networkInterface->str() << std::endl;
			}
		}
    }
    // print routes to module output
	if (par("dumpRoutes")) {
		for (int i = 0; i < topology.getNumNodes(); i++) {
			Node *node = (Node*) topology.getNode(i);
			if (node->routingTable) {
				std::cout << "== dumpRoutes Node " << node->module->getFullPath() << std::endl;
				check_and_cast<IIpv4RoutingTable*>(node->routingTable)->printRoutingTable();
				if (node->routingTable->getNumMulticastRoutes() > 0)
					check_and_cast<IIpv4RoutingTable*>(node->routingTable)->printMulticastRoutingTable();
			}
		}
	}

    // print current configuration to an XML file
    if (!opp_isempty(par("dumpConfig").stringValue()))
        TIME(dumpConfig(topology));
}

void Ipv4NetworkConfigurator::configureAllInterfaces()
{
    ensureConfigurationComputed(topology);
    EV_INFO << "Configuring all network interfaces.\n";
    for (int i = 0; i < topology.getNumNodes(); i++) {
        Node *node = (Node *)topology.getNode(i);
        for (auto& elem : node->interfaceInfos) {
            InterfaceInfo *interfaceInfo = static_cast<InterfaceInfo *>(elem);
            if (interfaceInfo->configure)
                configureInterface(interfaceInfo);
        }
    }
}

void Ipv4NetworkConfigurator::configureInterface(NetworkInterface *networkInterface)
{EV_INFO<<"Ipv4NetworkConfigurator::configureInterface(NetworkInterface *networkInterface)"<<endl;//std::cout<<"Ipv4NetworkConfigurator::configureInterface(NetworkInterface *networkInterface)"<<std::endl;
    ensureConfigurationComputed(topology);
    nmIdPair pkey = {networkInterface->getInterfaceTable()->getHostModule()->getId(), networkInterface->getId()};
    auto it = topology.interfaceInfos.find(pkey);
    if (it != topology.interfaceInfos.end()) {
        InterfaceInfo *interfaceInfo = static_cast<InterfaceInfo *>(it->second);
        if (interfaceInfo->configure)
            configureInterface(interfaceInfo);
    }
}

void Ipv4NetworkConfigurator::configureAllRoutingTables()
{
    ensureConfigurationComputed(topology);
    EV_INFO << "Configuring all routing tables.\n";
    for (int i = 0; i < topology.getNumNodes(); i++) {
        Node *node = (Node *)topology.getNode(i);
        if (node->routingTable)
            configureRoutingTable(node);
    }
}

void Ipv4NetworkConfigurator::configureRoutingTable(IIpv4RoutingTable *routingTable)
{EV_INFO<<"Ipv4NetworkConfigurator::configureRoutingTable(IIpv4RoutingTable *routingTable)"<<endl;
    ensureConfigurationComputed(topology);
    // TODO avoid linear search
    for (int i = 0; i < topology.getNumNodes(); i++) {
        Node *node = (Node *)topology.getNode(i);
        if (node->routingTable == routingTable)
            configureRoutingTable(node);
    }
}

void Ipv4NetworkConfigurator::configureRoutingTable(IIpv4RoutingTable *routingTable, NetworkInterface *networkInterface)
{EV_INFO<<"Ipv4NetworkConfigurator::configureRoutingTable(IIpv4RoutingTable *routingTable, NetworkInterface *networkInterface)"<<endl;
    ensureConfigurationComputed(topology);
    // TODO avoid linear search
    for (int i = 0; i < topology.getNumNodes(); i++) {
        Node *node = (Node *)topology.getNode(i);
        if (node->routingTable == routingTable)
            configureRoutingTable(node, networkInterface);
    }
}


static bool selectByProperty(cModule *mod, void *data)
{
    struct ParamData {
        const char *name;
        const char *value;
    };
    ParamData *d = (ParamData *)data;
    cProperty *prop = mod->getProperties()->get(d->name);
    if (!prop)
        return false;
    const char *value = prop->getValue(cProperty::DEFAULTKEY, 0);
    if (d->value)
        return opp_strcmp(value, d->value) == 0;
    else
        return opp_strcmp(value, "false") != 0;
}

int Ipv4NetworkConfigurator::getNumOfNonLocalNodes() {
	int numOfNonLocalNodes = 0;
	struct {
		const char *name;
		const char *value;
	} data = { "networkNode", nullptr };
	for (int modId = 0; modId <= getSimulation()->getLastComponentId(); modId++) {
		cModule *module = getSimulation()->getModule(modId);
		if (module && selectByProperty(module, (void *)&data)) {
			IInterfaceTable * ift = dynamic_cast<IInterfaceTable *>(module->getSubmodule("interfaceTable"));
			if (!ift) {
				numOfNonLocalNodes++;
			}
		}
	}
	return numOfNonLocalNodes;
}

int Ipv4NetworkConfigurator::getNumOfNonLocalEths() {
	int numOfNonLocalEths = 0;
	for (auto elem:topology.interfaceInfos) {
		int pid = getSimulation()->getEnvir()->getParsimProcId();
		if (find(cur_lp_nodeId[pid].begin(),cur_lp_nodeId[pid].end(),elem.first.nodeId)==cur_lp_nodeId[pid].end()) {
			numOfNonLocalEths++;
		}
	}
	return numOfNonLocalEths;
}

void Ipv4NetworkConfigurator::configureInterface(InterfaceInfo *interfaceInfo)
{
    EV_DETAIL << "Configuring network interface " << interfaceInfo->getFullPath() << ".\n";//std::cout<<"Configuring network interface "<<interfaceInfo->getFullPath()<<std::endl;
    NetworkInterface *networkInterface = interfaceInfo->networkInterface;
    auto interfaceData = networkInterface->getProtocolDataForUpdate<Ipv4InterfaceData>();
    if (interfaceInfo->mtu != -1)
        networkInterface->setMtu(interfaceInfo->mtu);
    if (interfaceInfo->metric != -1)
        interfaceData->setMetric(interfaceInfo->metric);
    if (assignAddressesParameter) {EV<<"ip = "<<Ipv4Address(interfaceInfo->address)<<endl;
        // std::stringstream ss;
        // ss <<"Rank "<<getSimulation()->getEnvir()->getParsimProcId()<<", configuring network interface "<<interfaceInfo->getFullPath()<<", ipaddr = "<<Ipv4Address(interfaceInfo->address);
        // std::cout<<ss.str()<<std::endl;
        interfaceData->setIPAddress(Ipv4Address(interfaceInfo->address));
        interfaceData->setNetmask(Ipv4Address(interfaceInfo->netmask));
    }
    // TODO should we leave joined multicast groups first?
    for (auto& multicastGroup : interfaceInfo->multicastGroups)
        interfaceData->joinMulticastGroup(multicastGroup);
}

void Ipv4NetworkConfigurator::configureRoutingTable(Node *node)
{
    EV_DETAIL << "Configuring routing table of " << node->getModule()->getFullPath() <<", staticroutes = "<<node->staticRoutes.size()<< ".\n";
    for (size_t i = 0; i < node->staticRoutes.size(); i++) {
        Ipv4Route *original = node->staticRoutes[i];
        Ipv4Route *clone = new Ipv4Route();
        clone->setMetric(original->getMetric());
        clone->setSourceType(original->getSourceType());
        clone->setSource(original->getSource());
        clone->setDestination(original->getDestination());
        clone->setNetmask(original->getNetmask());
        clone->setGateway(original->getGateway());
        clone->setInterface(original->getInterface());
        node->routingTable->addRoute(clone);
    }
    for (size_t i = 0; i < node->staticMulticastRoutes.size(); i++) {
        Ipv4MulticastRoute *original = node->staticMulticastRoutes[i];
        Ipv4MulticastRoute *clone = new Ipv4MulticastRoute();
        clone->setMetric(original->getMetric());
        clone->setSourceType(original->getSourceType());
        clone->setSource(original->getSource());
        clone->setOrigin(original->getOrigin());
        clone->setOriginNetmask(original->getOriginNetmask());
        clone->setInInterface(original->getInInterface());
        clone->setMulticastGroup(original->getMulticastGroup());
        for (size_t j = 0; j < original->getNumOutInterfaces(); j++)
            clone->addOutInterface(new IMulticastRoute::OutInterface(*original->getOutInterface(j)));
        node->routingTable->addMulticastRoute(clone);
    }
}

void Ipv4NetworkConfigurator::configureRoutingTable(Node *node, NetworkInterface *networkInterface)
{
    EV_DETAIL << "Configuring routing table of " << node->getModule()->getFullPath() << ", 2 parameters.\n";
    for (size_t i = 0; i < node->staticRoutes.size(); i++) {
        Ipv4Route *original = node->staticRoutes[i];
        if (original->getInterface() == networkInterface) {
            Ipv4Route *clone = new Ipv4Route();
            clone->setMetric(original->getMetric());
            clone->setSourceType(original->getSourceType());
            clone->setSource(original->getSource());
            clone->setDestination(original->getDestination());
            clone->setNetmask(original->getNetmask());
            clone->setGateway(original->getGateway());
            clone->setInterface(original->getInterface());
            node->routingTable->addRoute(clone);
        }
    }
    for (size_t i = 0; i < node->staticMulticastRoutes.size(); i++) {
        Ipv4MulticastRoute *original = node->staticMulticastRoutes[i];
        bool needed = original->getInInterface() && original->getInInterface()->getInterface() == networkInterface;
        for (size_t j = 0; !needed && j < original->getNumOutInterfaces(); j++)
            if (original->getOutInterface(j) && original->getOutInterface(j)->getInterface() == networkInterface)
                needed = true;

        if (needed) {
            Ipv4MulticastRoute *clone = new Ipv4MulticastRoute();
            clone->setMetric(original->getMetric());
            clone->setSourceType(original->getSourceType());
            clone->setSource(original->getSource());
            clone->setOrigin(original->getOrigin());
            clone->setOriginNetmask(original->getOriginNetmask());
            clone->setInInterface(original->getInInterface());
            clone->setMulticastGroup(original->getMulticastGroup());
            for (size_t j = 0; j < original->getNumOutInterfaces(); j++)
                clone->addOutInterface(new IMulticastRoute::OutInterface(*original->getOutInterface(j)));
            node->routingTable->addMulticastRoute(clone);
        }
    }
}

/**
 * Returns how many bits are needed to represent count different values.
 */
inline int getRepresentationBitCount(uint32_t count)
{
    int bitCount = 0;
    while (((uint32_t)1 << bitCount) < count)
        bitCount++;
    return bitCount;
}

/**
 * Returns the index of the most significant bit that equals to the given bit value.
 * 0 means the most significant bit.
 */
static int getMostSignificantBitIndex(uint32_t value, int bitValue, int defaultIndex)
{
    for (int bitIndex = sizeof(value) * 8 - 1; bitIndex >= 0; bitIndex--) {
        uint32_t mask = (uint32_t)1 << bitIndex;
        if ((value & mask) == ((uint32_t)bitValue << bitIndex))
            return bitIndex;
    }
    return defaultIndex;
}

/**
 * Returns the index of the least significant bit that equals to the given bit value.
 * 0 means the most significant bit.
 */
static int getLeastSignificantBitIndex(uint32_t value, int bitValue, int defaultIndex)
{
    for (int bitIndex = 0; bitIndex < ADDRLEN_BITS; bitIndex++) {
        uint32_t mask = (uint32_t)1 << bitIndex;
        if ((value & mask) == ((uint32_t)bitValue << bitIndex))
            return bitIndex;
    }
    return defaultIndex;
}

/**
 * Returns packed bits (subsequent) from value specified by mask (sparse).
 */
static uint32_t getPackedBits(uint32_t value, uint32_t valueMask)
{
    uint32_t packedValue = 0;
    int packedValueIndex = 0;
    for (int valueIndex = 0; valueIndex < ADDRLEN_BITS; valueIndex++) {
        uint32_t valueBitMask = (uint32_t)1 << valueIndex;
        if ((valueMask & valueBitMask) != 0) {
            if ((value & valueBitMask) != 0)
                packedValue |= (uint32_t)1 << packedValueIndex;
            packedValueIndex++;
        }
    }
    return packedValue;
}

/**
 * Set packed bits (subsequent) in value specified by mask (sparse).
 */
static uint32_t setPackedBits(uint32_t value, uint32_t valueMask, uint32_t packedValue)
{
    int packedValueIndex = 0;
    for (int valueIndex = 0; valueIndex < ADDRLEN_BITS; valueIndex++) {
        uint32_t valueBitMask = (uint32_t)1 << valueIndex;
        if ((valueMask & valueBitMask) != 0) {
            uint32_t newValueBitMask = (uint32_t)1 << packedValueIndex;
            if ((packedValue & newValueBitMask) != 0)
                value |= valueBitMask;
            else
                value &= ~valueBitMask;
            packedValueIndex++;
        }
    }
    return value;
}

bool Ipv4NetworkConfigurator::compareInterfaceInfos(InterfaceInfo *i, InterfaceInfo *j)
{
    return i->addressSpecifiedBits > j->addressSpecifiedBits;
}

/**
 * Returns a subset of the given interfaces that have compatible address and netmask specifications.
 * Determine the merged address and netmask specifications according to the following table.
 * The '?' symbol means the bit is unspecified, the 'X' symbol means the bit is incompatible.
 * | * | 0 | 1 | ? |
 * | 0 | 0 | X | 0 |
 * | 1 | X | 1 | 1 |
 * | ? | 0 | 1 | ? |
 */
void Ipv4NetworkConfigurator::collectCompatibleInterfaces(const std::vector<InterfaceInfo *>& interfaces, /*in*/
        std::vector<Ipv4NetworkConfigurator::InterfaceInfo *>& compatibleInterfaces, /*out, and the rest too*/
        uint32_t& mergedAddress, uint32_t& mergedAddressSpecifiedBits, uint32_t& mergedAddressIncompatibleBits,
        uint32_t& mergedNetmask, uint32_t& mergedNetmaskSpecifiedBits, uint32_t& mergedNetmaskIncompatibleBits)
{
    ASSERT(compatibleInterfaces.empty());
    mergedAddress = mergedAddressSpecifiedBits = mergedAddressIncompatibleBits = 0;
    mergedNetmask = mergedNetmaskSpecifiedBits = mergedNetmaskIncompatibleBits = 0;

    for (auto& interface : interfaces) {
        Ipv4NetworkConfigurator::InterfaceInfo *candidateInterface = interface;
        NetworkInterface *ie = candidateInterface->networkInterface;

        // extract candidate interface configuration data
        uint32_t candidateAddress = candidateInterface->address;
        uint32_t candidateAddressSpecifiedBits = candidateInterface->addressSpecifiedBits;
        uint32_t candidateNetmask = candidateInterface->netmask;
        uint32_t candidateNetmaskSpecifiedBits = candidateInterface->netmaskSpecifiedBits;
        EV_TRACE << "Trying to merge " << ie->getInterfaceFullPath() << " interface with address specification: " << Ipv4Address(candidateAddress) << " / " << Ipv4Address(candidateAddressSpecifiedBits) << endl;
        EV_TRACE << "Trying to merge " << ie->getInterfaceFullPath() << " interface with netmask specification: " << Ipv4Address(candidateNetmask) << " / " << Ipv4Address(candidateNetmaskSpecifiedBits) << endl;
        // std::cout << "Trying to merge " << ie->getInterfaceFullPath() << " interface with address specification: " << Ipv4Address(candidateAddress) << " / " << Ipv4Address(candidateAddressSpecifiedBits) << std::endl;
        // std::cout << "Trying to merge " << ie->getInterfaceFullPath() << " interface with netmask specification: " << Ipv4Address(candidateNetmask) << " / " << Ipv4Address(candidateNetmaskSpecifiedBits) << std::endl;
        // determine merged netmask bits
        uint32_t commonNetmaskSpecifiedBits = mergedNetmaskSpecifiedBits & candidateNetmaskSpecifiedBits;
        uint32_t newMergedNetmask = mergedNetmask | (candidateNetmask & candidateNetmaskSpecifiedBits);
        uint32_t newMergedNetmaskSpecifiedBits = mergedNetmaskSpecifiedBits | candidateNetmaskSpecifiedBits;
        uint32_t newMergedNetmaskIncompatibleBits = mergedNetmaskIncompatibleBits | ((mergedNetmask & commonNetmaskSpecifiedBits) ^ (candidateNetmask & commonNetmaskSpecifiedBits));

        // skip interface if there's a bit where the netmasks are incompatible
        if (newMergedNetmaskIncompatibleBits != 0)
            continue;

        // determine merged address bits
        uint32_t commonAddressSpecifiedBits = mergedAddressSpecifiedBits & candidateAddressSpecifiedBits;
        uint32_t newMergedAddress = mergedAddress | (candidateAddress & candidateAddressSpecifiedBits);
        uint32_t newMergedAddressSpecifiedBits = mergedAddressSpecifiedBits | candidateAddressSpecifiedBits;
        uint32_t newMergedAddressIncompatibleBits = mergedAddressIncompatibleBits | ((mergedAddress & commonAddressSpecifiedBits) ^ (candidateAddress & commonAddressSpecifiedBits));

        // skip interface if there's a bit where the netmask is 1 and the addresses are incompatible
        if ((newMergedNetmask & newMergedNetmaskSpecifiedBits & newMergedAddressIncompatibleBits) != 0)
            continue;

        // store merged address bits
        mergedAddress = newMergedAddress;
        mergedAddressSpecifiedBits = newMergedAddressSpecifiedBits;
        mergedAddressIncompatibleBits = newMergedAddressIncompatibleBits;

        // store merged netmask bits
        mergedNetmask = newMergedNetmask;
        mergedNetmaskSpecifiedBits = newMergedNetmaskSpecifiedBits;
        mergedNetmaskIncompatibleBits = newMergedNetmaskIncompatibleBits;

        // add interface to the list of compatible interfaces
        compatibleInterfaces.push_back(candidateInterface);
        EV_TRACE << "Merged address specification: " << Ipv4Address(mergedAddress) << " / " << Ipv4Address(mergedAddressSpecifiedBits) << " / " << Ipv4Address(mergedAddressIncompatibleBits) << endl;
        EV_TRACE << "Merged netmask specification: " << Ipv4Address(mergedNetmask) << " / " << Ipv4Address(mergedNetmaskSpecifiedBits) << " / " << Ipv4Address(mergedNetmaskIncompatibleBits) << endl;
        // std::cout << "Merged address specification: " << Ipv4Address(mergedAddress) << " / " << Ipv4Address(mergedAddressSpecifiedBits) << " / " << Ipv4Address(mergedAddressIncompatibleBits) << std::endl;
        // std::cout << "Merged netmask specification: " << Ipv4Address(mergedNetmask) << " / " << Ipv4Address(mergedNetmaskSpecifiedBits) << " / " << Ipv4Address(mergedNetmaskIncompatibleBits) << std::endl;
    }
    // sort compatibleInterfaces moving the most constrained interfaces first
    // (stable sort tp garantee identical order if the interfaces are similarly constrained)
    std::stable_sort(compatibleInterfaces.begin(), compatibleInterfaces.end(), compareInterfaceInfos);
    EV_TRACE << "Found " << compatibleInterfaces.size() << " compatible interfaces" << endl;
    // cout << "Found " << compatibleInterfaces.size() << " compatible interfaces" << endl;
}

void Ipv4NetworkConfigurator::assignAddresses(Topology& topology)
{//std::cout<<this->getFullPath()<<" assignAddresses(Topology) started.\n"<<std::endl;
    if (configureIsolatedNetworksSeparatly) {std::cout<<this->getFullPath()<<" configureIsolatedNetworksSeparatly started.\n"<<std::endl;
        std::map<int, std::vector<LinkInfo *>> isolatedNetworks;
        for (auto& linkInfo : topology.linkInfos) {
            int networkId = linkInfo->networkId;
            auto network = isolatedNetworks.find(networkId);
            if (network == isolatedNetworks.end()) {
                std::vector<LinkInfo *> collection = { linkInfo };
                isolatedNetworks[networkId] = collection;
            }
            else
                network->second.push_back(linkInfo);
        }
        for (auto& it : isolatedNetworks) {
            EV_DEBUG << "--> configuring isolated network " << it.first << ". \n";
            assignAddresses(it.second);
            EV_DEBUG << "<-- configuring isolated network " << it.first << ". \n";
        }
    }
    else
        assignAddresses(topology.linkInfos);
}

void Ipv4NetworkConfigurator::assignAddresses(std::vector<LinkInfo *> links)
{//std::cout<<this->getFullPath()<<" assignAddresses(vector) started.\n"<<std::endl;
    int bitSize = sizeof(uint32_t) * 8;
    std::vector<uint32_t> assignedNetworkAddresses;
    std::vector<uint32_t> assignedNetworkNetmasks;
    std::vector<uint32_t> assignedInterfaceAddresses;
    std::map<uint32_t, NetworkInterface *> assignedAddressToNetworkInterfaceMap;
    long assignAddressStartTime = clock();
    // cout << this->getFullPath() << "assignAddresses traverse num = "<<links.size()<< endl;
    long step1time,step2time,step3time,step4time=0;
    int iteNum=0;

    // iterate through all links and process them separately one by one
    for (auto& selectedLink : links) {//long traverseStartTime = clock();
        std::vector<InterfaceInfo *> unconfiguredInterfaces;

        if(enParsim){
            int id = getSimulation()->getEnvir()->getParsimProcId();
            for (auto& element : selectedLink->interfaceInfos){
                int ModId = element->node->module->getId();//cout<<"ModId = "<<ModId<<endl;
                if(find(cur_lp_nodeId[id].begin(),cur_lp_nodeId[id].end(),ModId)!=cur_lp_nodeId[id].end())
                unconfiguredInterfaces.push_back(static_cast<InterfaceInfo *>(element));
            }
            // cout <<"cur_lp "<<id<<" consist of: ";
            // for(auto it : unconfiguredInterfaces){
            //     cout<<it->node->module->getId()<<" ";
            // }cout<<endl;
        }else {
            for (auto& element : selectedLink->interfaceInfos)
            unconfiguredInterfaces.push_back(static_cast<InterfaceInfo *>(element));
        }
        
        // repeat until all interfaces of the selected link become configured
        // and assign addresses to groups of interfaces having compatible address and netmask specifications
        while (unconfiguredInterfaces.size() != 0) {
            // long step1StartTime = clock();
            // STEP 1.
            uint32_t mergedAddress; // compatible bits of the merged address (both 0 and 1 are address bits)
            uint32_t mergedAddressSpecifiedBits; // mask for the valid compatible bits of the merged address (0 means unspecified, 1 means specified)
            uint32_t mergedAddressIncompatibleBits; // incompatible bits of the merged address (0 means compatible, 1 means incompatible)
            uint32_t mergedNetmask; // compatible bits of the merged netmask (both 0 and 1 are netmask bits)
            uint32_t mergedNetmaskSpecifiedBits; // mask for the compatible bits of the merged netmask (0 means unspecified, 1 means specified)
            uint32_t mergedNetmaskIncompatibleBits; // incompatible bits of the merged netmask (0 means compatible, 1 means incompatible)
            std::vector<InterfaceInfo *> compatibleInterfaces; // the list of compatible interfaces
            collectCompatibleInterfaces(unconfiguredInterfaces, compatibleInterfaces, mergedAddress, mergedAddressSpecifiedBits, mergedAddressIncompatibleBits, mergedNetmask, mergedNetmaskSpecifiedBits, mergedNetmaskIncompatibleBits);
            // step1time += (clock() - step1StartTime);

            // long step2StartTime = clock();
            // STEP 2.
            // determine the valid range of netmask length by searching from left to right the last 1 and the first 0 bits
            // also consider the incompatible bits of the address to limit the range of valid netmasks accordingly
            int minimumNetmaskLength = bitSize - getLeastSignificantBitIndex(mergedNetmask & mergedNetmaskSpecifiedBits, 1, bitSize); // 0 means 0.0.0.0, bitSize means 255.255.255.255
            int maximumNetmaskLength = bitSize - 1 - getMostSignificantBitIndex(~mergedNetmask & mergedNetmaskSpecifiedBits, 1, -1); // 0 means 0.0.0.0, bitSize means 255.255.255.255
            maximumNetmaskLength = std::min(maximumNetmaskLength, bitSize - 1 - getMostSignificantBitIndex(mergedAddressIncompatibleBits, 1, -1));

            // make sure there are enough bits to configure a unique address for all interface
            // the +2 means that all-0 and all-1 addresses are ruled out
            int compatibleInterfaceCount = compatibleInterfaces.size() + 2;
            int interfaceAddressBitCount = getRepresentationBitCount(compatibleInterfaceCount);
            maximumNetmaskLength = std::min(maximumNetmaskLength, bitSize - interfaceAddressBitCount);
            EV_TRACE << "Netmask valid length range: " << minimumNetmaskLength << " - " << maximumNetmaskLength << endl;
            // step2time += (clock() - step2StartTime);

            // long step3StartTime = clock();
            // STEP 3.
            // determine network address and network netmask by iterating through valid netmasks from longest to shortest
            int netmaskLength = -1;
            uint32_t networkAddress = 0; // network part of the addresses  (e.g. 10.1.1.0)
            uint32_t networkNetmask = 0; // netmask for the network (e.g. 255.255.255.0)
            ASSERT(maximumNetmaskLength < bitSize);
            for (netmaskLength = maximumNetmaskLength; netmaskLength >= minimumNetmaskLength; netmaskLength--) {//long traverseStartTime = clock();
                ASSERT(netmaskLength < bitSize);
                networkNetmask = ~(~((uint32_t)0) >> netmaskLength);
                EV_TRACE << "Trying network netmask: " << Ipv4Address(networkNetmask) << " : " << netmaskLength << endl;
                networkAddress = mergedAddress & mergedAddressSpecifiedBits & networkNetmask;
                uint32_t networkAddressUnspecifiedBits = ~mergedAddressSpecifiedBits & networkNetmask; // 1 means the network address unspecified
                uint32_t networkAddressUnspecifiedPartLimit = getPackedBits(~(uint32_t)0, networkAddressUnspecifiedBits) + (uint32_t)1;
                EV_TRACE << "Counting from: " << 0 << " to: " << networkAddressUnspecifiedPartLimit << endl;

                // we start with +1 so that the network address will be more likely different
                for (uint32_t networkAddressUnspecifiedPart = 0; networkAddressUnspecifiedPart <= networkAddressUnspecifiedPartLimit; networkAddressUnspecifiedPart++) {
                    networkAddress = setPackedBits(networkAddress, networkAddressUnspecifiedBits, networkAddressUnspecifiedPart);
                    EV_TRACE << "Trying network address: " << Ipv4Address(networkAddress) << endl;
                    uint32_t networkAddressMaximum = networkAddress | ~networkNetmask;
                    // std::cout<<"line "<<__LINE__<<", ipaddr = "<<Ipv4Address(mergedAddress).str().c_str()<<", netmasklength = "<<netmaskLength<<", compatInterfaceCount = "<<compatibleInterfaceCount<<std::endl;
                    // check for overlapping network address ranges
                    if (assignDisjunctSubnetAddressesParameter) {
                        bool overlaps = false;
                        for (int i = 0; i < (int)assignedNetworkAddresses.size(); i++) {
                            uint32_t assignedNetworkAddress = assignedNetworkAddresses[i];
                            uint32_t assignedNetworkNetmask = assignedNetworkNetmasks[i];
                            uint32_t assignedNetworkAddressMaximum = assignedNetworkAddress | ~assignedNetworkNetmask;
                            // std::cout<<"networkAddress = "<<Ipv4Address(networkAddress).str().c_str()<<", asNetAddrMax = "<<Ipv4Address(assignedNetworkAddressMaximum).str().c_str()<<", asNetAddr = "<<Ipv4Address(assignedNetworkAddress).str().c_str()<<", netAddrMax = "<<Ipv4Address(networkAddressMaximum).str().c_str()<<std::endl;
                            if (networkAddress <= assignedNetworkAddressMaximum && assignedNetworkAddress <= networkAddressMaximum)
                                overlaps = true;
                        }
                        if (overlaps)
                            continue;
                    }
                    
                    // count interfaces that have the same address prefix
                    int interfaceCount = 0;
                    for (auto& assignedInterfaceAddress : assignedInterfaceAddresses)
                        if ((assignedInterfaceAddress & networkNetmask) == networkAddress)
                            interfaceCount++;

                    if (assignDisjunctSubnetAddressesParameter && interfaceCount != 0)
                        continue;
                    EV_TRACE << "Matching interface count: " << interfaceCount << endl;
                    
                    // std::cout<<"ipaddr = "<<Ipv4Address(mergedAddress).str().c_str()<<", netmasklength = "<<netmaskLength<<", interfaceCount = "<<interfaceCount<<", compatInterfaceCount = "<<compatibleInterfaceCount<<std::endl;
                    // check if there's enough room for the interface addresses
                    if ((1 << (bitSize - netmaskLength)) >= interfaceCount + compatibleInterfaceCount)
                        goto found;
                }//std::cout<<"out_loop, ipaddr = "<<Ipv4Address(mergedAddress).str().c_str()<<", netmasklength = "<<netmaskLength<<std::endl;
            }
          found: if (netmaskLength < minimumNetmaskLength || netmaskLength > maximumNetmaskLength) {
        	  	//   std::cout << "netmaskLength:" << netmaskLength << ",minimumNetmaskLength:" << minimumNetmaskLength << ",maximumNetmaskLength:" << maximumNetmaskLength << std::endl;
                throw cRuntimeError("Failed to find address prefix (using %s with specified bits %s) and netmask (length from %d bits to %d bits) for interface %s and %zu other interface(s). Please refine your parameters and try again!",
                        Ipv4Address(mergedAddress).str().c_str(), Ipv4Address(mergedAddressSpecifiedBits).str().c_str(), minimumNetmaskLength, maximumNetmaskLength,
                        compatibleInterfaces[0]->networkInterface->getInterfaceFullPath().c_str(), compatibleInterfaces.size() - 1);
          }
            EV_TRACE << "Selected netmask length: " << netmaskLength << endl;
            EV_TRACE << "Selected network address: " << Ipv4Address(networkAddress) << endl;
            EV_TRACE << "Selected network netmask: " << Ipv4Address(networkNetmask) << endl;
            // step3time += (clock() - step3StartTime);

            // long step4StartTime = clock();
            // STEP 4.
            // determine the complete IP address for all compatible interfaces
            for (auto& compatibleInterface : compatibleInterfaces) {
                NetworkInterface *networkInterface = compatibleInterface->networkInterface;
                uint32_t interfaceAddress = compatibleInterface->address & ~networkNetmask;
                uint32_t interfaceAddressSpecifiedBits = compatibleInterface->addressSpecifiedBits;

                uint32_t interfaceAddressUnspecifiedBits = ~interfaceAddressSpecifiedBits & ~networkNetmask; // 1 means the interface address is unspecified
                uint32_t interfaceAddressUnspecifiedPartMaximum = 0;
                for (auto& assignedInterfaceAddress : assignedInterfaceAddresses) {
                    uint32_t otherInterfaceAddress = assignedInterfaceAddress;
                    if ((otherInterfaceAddress & ~interfaceAddressUnspecifiedBits) == ((networkAddress | interfaceAddress) & ~interfaceAddressUnspecifiedBits)) {
                        uint32_t otherInterfaceAddressUnspecifiedPart = getPackedBits(otherInterfaceAddress, interfaceAddressUnspecifiedBits);
                        if (otherInterfaceAddressUnspecifiedPart > interfaceAddressUnspecifiedPartMaximum)
                            interfaceAddressUnspecifiedPartMaximum = otherInterfaceAddressUnspecifiedPart;
                    }
                }
                interfaceAddressUnspecifiedPartMaximum++;
                interfaceAddress = setPackedBits(interfaceAddress, interfaceAddressUnspecifiedBits, interfaceAddressUnspecifiedPartMaximum);

                // determine the complete address and netmask for interface
                uint32_t completeAddress = networkAddress | interfaceAddress;
                uint32_t completeNetmask = networkNetmask;

                // check if we could really find a unique IP address
                if (assignUniqueAddresses && containsKey(assignedAddressToNetworkInterfaceMap, completeAddress))
                    throw cRuntimeError("Failed to configure unique address for %s. Please refine your parameters and try again!", networkInterface->getInterfaceFullPath().c_str());
                assignedAddressToNetworkInterfaceMap[completeAddress] = compatibleInterface->networkInterface;
                assignedInterfaceAddresses.push_back(completeAddress);

                // configure interface with the selected address and netmask
                EV_DEBUG << "Setting interface address, interface = " << compatibleInterface->getFullPath() << ", address = " << Ipv4Address(completeAddress) << ", netmask = " << Ipv4Address(completeNetmask) << endl;
                compatibleInterface->address = completeAddress;
                compatibleInterface->addressSpecifiedBits = 0xFFFFFFFF;
                compatibleInterface->netmask = completeNetmask;
                compatibleInterface->netmaskSpecifiedBits = 0xFFFFFFFF;
                // std::cout << "Setting interface address, interface = " << compatibleInterface->getFullPath() << ", address = " << Ipv4Address(completeAddress) << ", netmask = " << Ipv4Address(completeNetmask) << std::endl;

                // remove configured interface
                unconfiguredInterfaces.erase(find(unconfiguredInterfaces, compatibleInterface));
            }

            // register the network address and netmask as being used
            assignedNetworkAddresses.push_back(networkAddress);
            assignedNetworkNetmasks.push_back(networkNetmask);
            // step4time += (clock() - step4StartTime);
        }//cout << this->getFullPath() << "assignAddresses one traverse time: " << (static_cast<double>(clock() - traverseStartTime) / CLOCKS_PER_SEC) << "s" << endl;
    }
    //cout << this->getFullPath() << ", step1time: " << (static_cast<double>(step1time)/CLOCKS_PER_SEC) << "s, step2time: "<< (static_cast<double>(step2time)/CLOCKS_PER_SEC) <<"s, step3time: " << (static_cast<double>(step3time)/CLOCKS_PER_SEC) <<"s, step4time: "<< (static_cast<double>(step4time)/CLOCKS_PER_SEC) << endl;
    //std::cout<<this->getFullPath()<<" assignAddresses(vector) finished.\n"<<std::endl;
}

Ipv4NetworkConfigurator::InterfaceInfo *Ipv4NetworkConfigurator::createInterfaceInfo(L3NetworkConfiguratorBase::Topology& topology, L3NetworkConfiguratorBase::Node *node, LinkInfo *linkInfo, NetworkInterface *ie)
{
    InterfaceInfo *interfaceInfo = new InterfaceInfo(static_cast<Ipv4NetworkConfigurator::Node *>(node), linkInfo, ie);
    auto ipv4Data = ie->findProtocolDataForUpdate<Ipv4InterfaceData>();
    if (ipv4Data) {
        Ipv4Address address = ipv4Data->getIPAddress();
        Ipv4Address netmask = ipv4Data->getNetmask();
        if (!address.isUnspecified()) {
            interfaceInfo->address = address.getInt();
            interfaceInfo->addressSpecifiedBits = 0xFFFFFFFF;
            interfaceInfo->netmask = netmask.getInt();
            interfaceInfo->netmaskSpecifiedBits = 0xFFFFFFFF;
        }
    }
    node->interfaceInfos.push_back(interfaceInfo);
    nmIdPair pkey = {node->getModuleId(), ie->getId()};
    topology.interfaceInfos[pkey] = interfaceInfo;
    return interfaceInfo;
}

void Ipv4NetworkConfigurator::readInterfaceConfiguration(Topology& topology)
{
    using namespace xmlutils;

    std::set<InterfaceInfo *> interfacesSeen;
    cXMLElementList interfaceElements = configuration->getChildrenByTagName("interface");

    for (auto& interfaceElement : interfaceElements) {
        const char *hostAttr = interfaceElement->getAttribute("hosts"); // "host* router[0..3]"
        const char *interfaceAttr = interfaceElement->getAttribute("names"); // i.e. interface names, like "eth* ppp0"

        // TODO "switch" egyebkent sztem nem muxik most, de kellene!
        const char *towardsAttr = interfaceElement->getAttribute("towards"); // neighbor host names, like "ap switch"
        const char *amongAttr = interfaceElement->getAttribute("among"); // neighbor host names, like "host[*] router1"
        const char *addressAttr = interfaceElement->getAttribute("address"); // "10.0.x.x"
        const char *netmaskAttr = interfaceElement->getAttribute("netmask"); // "255.255.x.x"
        const char *mtuAttr = interfaceElement->getAttribute("mtu"); // integer
        const char *metricAttr = interfaceElement->getAttribute("metric"); // integer
        const char *groupsAttr = interfaceElement->getAttribute("groups"); // list of multicast addresses
        bool addStaticRouteAttr = getAttributeBoolValue(interfaceElement, "add-static-route", true);
        bool addDefaultRouteAttr = getAttributeBoolValue(interfaceElement, "add-default-route", true);
        bool addSubnetRouteAttr = getAttributeBoolValue(interfaceElement, "add-subnet-route", true);
// std::cout<<"hostAttr = "<<hostAttr<<", addressAttr = "<<addressAttr<<", netmastAttr = "<<netmaskAttr<<std::endl;
        if (amongAttr && *amongAttr) { // among="X Y Z" means hosts = "X Y Z" towards = "X Y Z"
            if ((hostAttr && *hostAttr) || (towardsAttr && *towardsAttr))
                throw cRuntimeError("The 'hosts'/'towards' and 'among' attributes are mutually exclusive, at %s", interfaceElement->getSourceLocation());
            towardsAttr = hostAttr = amongAttr;
        }

        try {
            // parse host/interface/towards expressions
            Matcher hostMatcher(hostAttr);
            Matcher interfaceMatcher(interfaceAttr);
            Matcher towardsMatcher(towardsAttr);

            // parse address/netmask constraints
            bool haveAddressConstraint = !opp_isempty(addressAttr);
            bool haveNetmaskConstraint = !opp_isempty(netmaskAttr);

            uint32_t address, addressSpecifiedBits, netmask, netmaskSpecifiedBits;
            if (haveAddressConstraint)
                parseAddressAndSpecifiedBits(addressAttr, address, addressSpecifiedBits);
            if (haveNetmaskConstraint) {
                if (netmaskAttr[0] == '/') {
                    netmask = Ipv4Address::makeNetmask(atoi(netmaskAttr + 1)).getInt();
                    netmaskSpecifiedBits = 0xffffffffLU;
                }
                else
                    parseAddressAndSpecifiedBits(netmaskAttr, netmask, netmaskSpecifiedBits);
            }
            // configure address/netmask constraints on matching interfaces
            for (auto& linkInfo : topology.linkInfos) {
                for (int j = 0; j < (int)linkInfo->interfaceInfos.size(); j++) {
                    InterfaceInfo *interfaceInfo = static_cast<InterfaceInfo *>(linkInfo->interfaceInfos[j]);
                    if (interfacesSeen.count(interfaceInfo) == 0) {
//                        cModule *hostModule = interfaceInfo->networkInterface->getInterfaceTable()->getHostModule();
                        cModule *hostModule = interfaceInfo->node->interfaceTable->getHostModule();
                        std::string hostFullPath = hostModule->getFullPath();
                        std::string hostShortenedFullPath = hostFullPath.substr(hostFullPath.find('.') + 1);

                        // Note: "hosts", "interfaces" and "towards" must ALL match on the interface for the rule to apply
                        if ((hostMatcher.matchesAny() || hostMatcher.matches(hostShortenedFullPath.c_str()) || hostMatcher.matches(hostFullPath.c_str())) &&
                            (interfaceMatcher.matchesAny() || interfaceMatcher.matches(interfaceInfo->networkInterface->getInterfaceName())) &&
                            (towardsMatcher.matchesAny() || linkContainsMatchingHostExcept(linkInfo, &towardsMatcher, hostModule)))
                        {
                            EV_DEBUG << "Processing interface configuration for " << interfaceInfo->getFullPath() << endl;

                            // unicast address constraints
                            interfaceInfo->configure = haveAddressConstraint;
                            if (interfaceInfo->configure) {
                                interfaceInfo->address = address;
                                interfaceInfo->addressSpecifiedBits = addressSpecifiedBits;
                                if (haveNetmaskConstraint) {
                                    interfaceInfo->netmask = netmask;
                                    interfaceInfo->netmaskSpecifiedBits = netmaskSpecifiedBits;
                                }
                            }

                            // route flags
                            interfaceInfo->addStaticRoute = addStaticRouteAttr;
                            interfaceInfo->addDefaultRoute = addDefaultRouteAttr;
                            interfaceInfo->addSubnetRoute = addSubnetRouteAttr;

                            // mtu
                            if (!opp_isempty(mtuAttr))
                                interfaceInfo->mtu = atoi(mtuAttr);

                            // metric
                            if (!opp_isempty(metricAttr))
                                interfaceInfo->metric = atoi(metricAttr);

                            // groups
                            if (!opp_isempty(groupsAttr)) {
                                cStringTokenizer tokenizer(groupsAttr);
                                while (tokenizer.hasMoreTokens())
                                    interfaceInfo->multicastGroups.push_back(Ipv4Address(tokenizer.nextToken()));
                            }

                            interfacesSeen.insert(interfaceInfo);
                        }
                    }
                }
            }
        }
        catch (std::exception& e) {
            throw cRuntimeError("Error in XML <interface> element at %s: %s", interfaceElement->getSourceLocation(), e.what());
        }
    }
}

void Ipv4NetworkConfigurator::parseAddressAndSpecifiedBits(const char *addressAttr, uint32_t& outAddress, uint32_t& outAddressSpecifiedBits)
{
    // change "10.0.x.x" to "10.0.0.0" (for address) and "255.255.0.0" (for specifiedBits)
    std::string address;
    std::string specifiedBits;
    cStringTokenizer tokenizer(addressAttr, ".");
    while (tokenizer.hasMoreTokens()) {
        std::string token = tokenizer.nextToken();
        address += (token == "x") ? "0." : (token + ".");
        specifiedBits += (token == "x") ? "0." : "255.";
    }
    address = address.substr(0, address.size() - 1);
    specifiedBits = specifiedBits.substr(0, specifiedBits.size() - 1);

    if (!Ipv4Address::isWellFormed(address.c_str()) || !Ipv4Address::isWellFormed(specifiedBits.c_str()))
        throw cRuntimeError("Malformed Ipv4 address or netmask constraint '%s'", addressAttr);

    outAddress = Ipv4Address(address.c_str()).getInt();
    outAddressSpecifiedBits = Ipv4Address(specifiedBits.c_str()).getInt();
}

bool Ipv4NetworkConfigurator::linkContainsMatchingHostExcept(LinkInfo *linkInfo, Matcher *hostMatcher, cModule *exceptModule)
{
    for (auto& element : linkInfo->interfaceInfos) {
        InterfaceInfo *interfaceInfo = static_cast<InterfaceInfo *>(element);
        cModule *hostModule = interfaceInfo->networkInterface->getInterfaceTable()->getHostModule();
        if (hostModule == exceptModule)
            continue;
        std::string hostFullPath = hostModule->getFullPath();
        std::string hostShortenedFullPath = hostFullPath.substr(hostFullPath.find('.') + 1);
        if (hostMatcher->matches(hostShortenedFullPath.c_str()) || hostMatcher->matches(hostFullPath.c_str()))
            return true;
    }
    return false;
}

void Ipv4NetworkConfigurator::dumpLinks(Topology& topology)
{
    for (size_t i = 0; i < topology.linkInfos.size(); i++) {
        EV_INFO << "Link " << i << endl;
        LinkInfo *linkInfo = topology.linkInfos[i];
        for (auto& element : linkInfo->interfaceInfos) {
            InterfaceInfo *interfaceInfo = static_cast<InterfaceInfo *>(element);
            EV_INFO << "     " << interfaceInfo->networkInterface->getInterfaceFullPath() << endl;
        }
    }
}

void Ipv4NetworkConfigurator::dumpAddresses(Topology& topology)
{
    for (size_t i = 0; i < topology.linkInfos.size(); i++) {
        EV_INFO << "Link " << i << endl;
        LinkInfo *linkInfo = topology.linkInfos[i];
        for (auto& interfaceInfo : linkInfo->interfaceInfos) {
            NetworkInterface *networkInterface = interfaceInfo->networkInterface;
            cModule *host = interfaceInfo->node->module;
            EV_INFO << "    " << host->getFullName() << " / " << networkInterface->str() << endl;
        }
    }
}

void Ipv4NetworkConfigurator::dumpRoutes(Topology& topology)
{
    for (int i = 0; i < topology.getNumNodes(); i++) {
        Node *node = (Node *)topology.getNode(i);
        if (node->routingTable) {
            EV_INFO << "Node " << node->module->getFullPath() << endl;
            check_and_cast<IIpv4RoutingTable *>(node->routingTable)->printRoutingTable();
            if (node->routingTable->getNumMulticastRoutes() > 0)
                check_and_cast<IIpv4RoutingTable *>(node->routingTable)->printMulticastRoutingTable();
        }
    }
}

void Ipv4NetworkConfigurator::dumpConfig(Topology& topology)
{
    FILE *f;
    const char *filename = par("dumpConfig");
    inet::utils::makePathForFile(filename);
    f = fopen(filename, "w");
    if (!f)
        throw cRuntimeError("Cannot write configurator output file");
    fprintf(f, "<config>\n");

    // interfaces
    for (auto& linkInfo : topology.linkInfos) {
        for (auto& element : linkInfo->interfaceInfos) {
            InterfaceInfo *interfaceInfo = static_cast<InterfaceInfo *>(element);
            NetworkInterface *networkInterface = interfaceInfo->networkInterface;
            auto interfaceData = networkInterface->getProtocolData<Ipv4InterfaceData>();
            std::stringstream stream;
            stream << "   <interface hosts=\"" << interfaceInfo->node->module->getFullPath() << "\" names=\"" << networkInterface->getInterfaceName()
                   << "\" address=\"" << interfaceData->getIPAddress() << "\" netmask=\"" << interfaceData->getNetmask()
                   << "\" metric=\"" << interfaceData->getMetric()
                   << "\"/>" << endl;
            fprintf(f, "%s", stream.str().c_str());
        }
    }

    // multicast groups
    for (auto& linkInfo : topology.linkInfos) {
        for (auto& element : linkInfo->interfaceInfos) {
            InterfaceInfo *interfaceInfo = static_cast<InterfaceInfo *>(element);
            NetworkInterface *networkInterface = interfaceInfo->networkInterface;
            const auto& interfaceData = networkInterface->getProtocolData<Ipv4InterfaceData>();
            int numOfMulticastGroups = interfaceData->getNumOfJoinedMulticastGroups();
            if (numOfMulticastGroups > 0) {
                std::stringstream stream;
                stream << "   <multicast-group hosts=\"" << interfaceInfo->node->module->getFullPath() << "\" interfaces=\"" << networkInterface->getInterfaceName() << "\" address=\"";
                for (int k = 0; k < numOfMulticastGroups; k++) {
                    Ipv4Address address = interfaceData->getJoinedMulticastGroup(k);
                    if (k)
                        stream << " ";
                    stream << address.str();
                }
                stream << "\"/>" << endl;
                fprintf(f, "%s", stream.str().c_str());
            }
        }
    }

    // wireless links
    for (auto& linkInfo : topology.linkInfos) {
        bool hasWireless = false;
        for (auto& element : linkInfo->interfaceInfos) {
            InterfaceInfo *interfaceInfo = static_cast<InterfaceInfo *>(element);
            if (interfaceInfo->networkInterface->isWireless())
                hasWireless = true;
        }
        if (hasWireless) {
            bool first = true;
            std::stringstream stream;
            stream << "   <wireless interfaces=\"";
            for (auto& element : linkInfo->interfaceInfos) {
                if (!first)
                    stream << " ";
                InterfaceInfo *interfaceInfo = static_cast<InterfaceInfo *>(element);
                if (interfaceInfo->networkInterface->isWireless()) {
                    stream << interfaceInfo->node->module->getFullPath() << "%" << interfaceInfo->networkInterface->getInterfaceName();
                    first = false;
                }
            }
            stream << "\"/>" << endl;
            fprintf(f, "%s", stream.str().c_str());
        }
    }

    // routes
    for (int i = 0; i < topology.getNumNodes(); i++) {
        Node *node = (Node *)topology.getNode(i);
        IIpv4RoutingTable *routingTable = dynamic_cast<IIpv4RoutingTable *>(node->routingTable);
        if (routingTable) {
            for (int j = 0; j < routingTable->getNumRoutes(); j++) {
                Ipv4Route *route = routingTable->getRoute(j);
                std::stringstream stream;
                Ipv4Address netmask = route->getNetmask();
                Ipv4Address gateway = route->getGateway();
                stream << "   <route hosts=\"" << node->module->getFullPath();
                stream << "\" destination=\"";
                if (route->getDestination().isUnspecified())
                    stream << "*";
                else
                    stream << route->getDestination();
                stream << "\" netmask=\"";
                if (route->getNetmask().isUnspecified())
                    stream << "*";
                else
                    stream << route->getNetmask();
                stream << "\" gateway=\"";
                if (route->getGateway().isUnspecified())
                    stream << "*";
                else
                    stream << route->getGateway();
                stream << "\" interface=\"" << route->getInterfaceName() << "\" metric=\"" << route->getMetric() << "\"/>" << endl;
                fprintf(f, "%s", stream.str().c_str());
            }
        }
    }

    // multicast routes
    for (int i = 0; i < topology.getNumNodes(); i++) {
        Node *node = (Node *)topology.getNode(i);
        IIpv4RoutingTable *routingTable = dynamic_cast<IIpv4RoutingTable *>(node->routingTable);
        if (routingTable) {
            for (int j = 0; j < routingTable->getNumMulticastRoutes(); j++) {
                Ipv4MulticastRoute *route = routingTable->getMulticastRoute(j);
                std::stringstream stream;
                stream << "   <multicast-route hosts=\"" << node->module->getFullPath();
                stream << "\" source=\"";
                if (route->getOrigin().isUnspecified())
                    stream << "*";
                else
                    stream << route->getOrigin();
                stream << "\" netmask=\"";
                if (route->getOriginNetmask().isUnspecified())
                    stream << "*";
                else
                    stream << route->getOriginNetmask();
                stream << "\" groups=\"";
                if (route->getMulticastGroup().isUnspecified())
                    stream << "*";
                else
                    stream << route->getMulticastGroup();
                if (route->getInInterface())
                    stream << "\" parent=\"" << route->getInInterface()->getInterface()->getInterfaceName();
                stream << "\" children=\"";
                for (unsigned int k = 0; k < route->getNumOutInterfaces(); k++) {
                    if (k)
                        stream << " ";
                    stream << route->getOutInterface(k)->getInterface()->getInterfaceName();
                }
                stream << "\" metric=\"" << route->getMetric() << "\"/>" << endl;
                fprintf(f, "%s", stream.str().c_str());
            }
        }
    }

    fprintf(f, "</config>");
    fflush(f);
    fclose(f);
}

void Ipv4NetworkConfigurator::readMulticastGroupConfiguration(Topology& topology)
{
    cXMLElementList multicastGroupElements = configuration->getChildrenByTagName("multicast-group");
    for (auto& multicastGroupElement : multicastGroupElements) {
        const char *hostAttr = multicastGroupElement->getAttribute("hosts");
        const char *interfaceAttr = multicastGroupElement->getAttribute("interfaces");
        const char *addressAttr = multicastGroupElement->getAttribute("address");
        const char *towardsAttr = multicastGroupElement->getAttribute("towards"); // neighbor host names, like "ap switch"
        const char *amongAttr = multicastGroupElement->getAttribute("among");

        if (amongAttr && *amongAttr) { // among="X Y Z" means hosts = "X Y Z" towards = "X Y Z"
            if ((hostAttr && *hostAttr) || (towardsAttr && *towardsAttr))
                throw cRuntimeError("The 'hosts'/'towards' and 'among' attributes are mutually exclusive, at %s", multicastGroupElement->getSourceLocation());
            towardsAttr = hostAttr = amongAttr;
        }

        try {
            Matcher hostMatcher(hostAttr);
            Matcher interfaceMatcher(interfaceAttr);
            Matcher towardsMatcher(towardsAttr);

            // parse group addresses
            std::vector<Ipv4Address> multicastGroups;
            cStringTokenizer tokenizer(addressAttr);
            while (tokenizer.hasMoreTokens()) {
                Ipv4Address addr = Ipv4Address(tokenizer.nextToken());
                if (!addr.isMulticast())
                    throw cRuntimeError("Non-multicast address %s found in the multicast-group element", addr.str().c_str());
                multicastGroups.push_back(addr);
            }

            for (auto& linkInfo : topology.linkInfos) {
                for (size_t k = 0; k < linkInfo->interfaceInfos.size(); k++) {
                    InterfaceInfo *interfaceInfo = static_cast<InterfaceInfo *>(linkInfo->interfaceInfos[k]);
                    cModule *hostModule = interfaceInfo->networkInterface->getInterfaceTable()->getHostModule();
                    std::string hostFullPath = hostModule->getFullPath();
                    std::string hostShortenedFullPath = hostFullPath.substr(hostFullPath.find('.') + 1);

                    if ((hostMatcher.matchesAny() || hostMatcher.matches(hostShortenedFullPath.c_str()) || hostMatcher.matches(hostFullPath.c_str())) &&
                        (interfaceMatcher.matchesAny() || interfaceMatcher.matches(interfaceInfo->networkInterface->getInterfaceName())) &&
                        (towardsMatcher.matchesAny() || linkContainsMatchingHostExcept(linkInfo, &towardsMatcher, hostModule)))
                    {
                        for (auto& multicastGroup : multicastGroups)
                            interfaceInfo->multicastGroups.push_back(multicastGroup);
                    }
                }
            }
        }
        catch (std::exception& e) {
            throw cRuntimeError("Error in XML <multicast-group> element at %s: %s", multicastGroupElement->getSourceLocation(), e.what());
        }
    }
}

void Ipv4NetworkConfigurator::readManualRouteConfiguration(Topology& topology)
{EV_INFO<<"Ipv4NetworkConfigurator::readManualRouteConfiguration(Topology& topology)"<<endl;
    cXMLElementList routeElements = configuration->getChildrenByTagName("route");
    for (auto& routeElement : routeElements) {
        const char *hostAttr = xmlutils::getMandatoryFilledAttribute(*routeElement, "hosts");
        const char *destinationAttr = xmlutils::getMandatoryAttribute(*routeElement, "destination"); // destination address  (L3AddressResolver syntax)
        const char *netmaskAttr = routeElement->getAttribute("netmask"); // default: 255.255.255.255; alternative notation: "/23"
        const char *gatewayAttr = routeElement->getAttribute("gateway"); // next hop address (L3AddressResolver syntax)
        const char *interfaceAttr = routeElement->getAttribute("interface"); // output interface name
        const char *metricAttr = routeElement->getAttribute("metric");

        try {
            // parse and check the attributes
            Ipv4Address destination;
            if (!opp_isempty(destinationAttr) && strcmp(destinationAttr, "*"))
                destination = resolve(destinationAttr, L3AddressResolver::ADDR_IPv4).toIpv4();
            Ipv4Address netmask;
            if (!opp_isempty(netmaskAttr) && strcmp(netmaskAttr, "*")) {
                if (netmaskAttr[0] == '/')
                    netmask = Ipv4Address::makeNetmask(atoi(netmaskAttr + 1));
                else
                    netmask = Ipv4Address(netmaskAttr);
            }
            if (!netmask.isValidNetmask())
                throw cRuntimeError("Wrong netmask %s", netmask.str().c_str());
            if (opp_isempty(interfaceAttr) && opp_isempty(gatewayAttr))
                throw cRuntimeError("Incomplete route: either gateway or interface (or both) must be specified");

            // find matching host(s), and add the route
            Matcher atMatcher(hostAttr);
            for (int i = 0; i < topology.getNumNodes(); i++) {
                Node *node = (Node *)topology.getNode(i);
                if (node->routingTable) {
                    std::string hostFullPath = node->module->getFullPath();
                    std::string hostShortenedFullPath = hostFullPath.substr(hostFullPath.find('.') + 1);
                    if (atMatcher.matches(hostShortenedFullPath.c_str()) || atMatcher.matches(hostFullPath.c_str())) {
                        // determine the gateway (its address towards this node!) and the output interface for the route (must be done per node)
                        NetworkInterface *ie;
                        Ipv4Address gateway;
                        resolveInterfaceAndGateway(node, interfaceAttr, gatewayAttr, ie, gateway, topology);

                        // create and add route
                        Ipv4Route *route = new Ipv4Route();
                        route->setSourceType(IRoute::MANUAL);
                        route->setDestination(destination);
                        route->setNetmask(netmask);
                        route->setGateway(gateway); // may be unspecified
                        route->setInterface(ie);
                        if (!opp_isempty(metricAttr))
                            route->setMetric(atoi(metricAttr));
                        node->staticRoutes.push_back(route);
                    }
                }
            }
        }
        catch (std::exception& e) {
            throw cRuntimeError("Error in XML <route> element at %s: %s", routeElement->getSourceLocation(), e.what());
        }
    }
}

void Ipv4NetworkConfigurator::readManualMulticastRouteConfiguration(Topology& topology)
{
    cXMLElementList routeElements = configuration->getChildrenByTagName("multicast-route");
    for (auto& routeElement : routeElements) {
        const char *hostAttr = routeElement->getAttribute("hosts");
        const char *sourceAttr = routeElement->getAttribute("source"); // source address  (L3AddressResolver syntax)
        const char *netmaskAttr = routeElement->getAttribute("netmask"); // default: 255.255.255.255; alternative notation: "/23"
        const char *groupsAttr = routeElement->getAttribute("groups"); // addresses of the multicast groups, default: 0.0.0.0, matching all groups
        const char *parentAttr = routeElement->getAttribute("parent"); // name of expected input interface
        const char *childrenAttr = routeElement->getAttribute("children"); // names of output interfaces
        const char *metricAttr = routeElement->getAttribute("metric");

        try {
            // parse and check the attributes
            Ipv4Address source;
            if (!opp_isempty(sourceAttr) && strcmp(sourceAttr, "*"))
                source = resolve(sourceAttr, L3AddressResolver::ADDR_IPv4).toIpv4();
            Ipv4Address netmask;
            if (!opp_isempty(netmaskAttr) && strcmp(netmaskAttr, "*")) {
                if (netmaskAttr[0] == '/')
                    netmask = Ipv4Address::makeNetmask(atoi(netmaskAttr + 1));
                else
                    netmask = Ipv4Address(netmaskAttr);
            }

            if (!netmask.isValidNetmask())
                throw cRuntimeError("Wrong netmask %s", netmask.str().c_str());

            std::vector<Ipv4Address> groups;
            if (opp_isempty(groupsAttr))
                groups.push_back(Ipv4Address::UNSPECIFIED_ADDRESS);
            else {
                cStringTokenizer tokenizer(groupsAttr);
                while (tokenizer.hasMoreTokens()) {
                    Ipv4Address group = Ipv4Address(tokenizer.nextToken());
                    if (!group.isMulticast())
                        throw cRuntimeError("Address '%s' in groups attribute is not multicast.", group.str().c_str());
                    groups.push_back(group);
                }
            }

            // find matching host(s), and add the route
            Matcher atMatcher(hostAttr);
            InterfaceMatcher childrenMatcher(childrenAttr);
            for (int i = 0; i < topology.getNumNodes(); i++) {
                Node *node = (Node *)topology.getNode(i);
                if (node->routingTable && node->routingTable->isMulticastForwardingEnabled()) {
                    std::string hostFullPath = node->module->getFullPath();
                    std::string hostShortenedFullPath = hostFullPath.substr(hostFullPath.find('.') + 1);
                    if (atMatcher.matches(hostShortenedFullPath.c_str()) || atMatcher.matches(hostFullPath.c_str())) {
                        NetworkInterface *parent = nullptr;
                        if (!opp_isempty(parentAttr)) {
                            parent = node->interfaceTable->findInterfaceByName(parentAttr);
                            if (!parent)
                                throw cRuntimeError("Parent interface '%s' not found.", parentAttr);
                            if (!parent->isMulticast())
                                throw cRuntimeError("Parent interface '%s' is not multicast.", parentAttr);
                        }

                        std::vector<NetworkInterface *> children;
                        for (auto& element : node->interfaceInfos) {
                            InterfaceInfo *interfaceInfo = static_cast<InterfaceInfo *>(element);
                            NetworkInterface *ie = interfaceInfo->networkInterface;
                            if (ie != parent && ie->isMulticast() && childrenMatcher.matches(interfaceInfo))
                                children.push_back(ie);
                        }

                        for (auto& group : groups) {
                            // create and add route
                            Ipv4MulticastRoute *route = new Ipv4MulticastRoute();
                            route->setSourceType(IMulticastRoute::MANUAL);
                            route->setOrigin(source);
                            route->setOriginNetmask(netmask);
                            route->setMulticastGroup(group);
                            route->setInInterface(parent ? new Ipv4MulticastRoute::InInterface(parent) : nullptr);
                            if (!opp_isempty(metricAttr))
                                route->setMetric(atoi(metricAttr));
                            for (auto& child : children)
                                route->addOutInterface(new Ipv4MulticastRoute::OutInterface(child, false /*TODOisLeaf*/));
                            node->staticMulticastRoutes.push_back(route);
                        }
                    }
                }
            }
        }
        catch (std::exception& e) {
            throw cRuntimeError("Error in XML <multicast-route> element at %s: %s", routeElement->getSourceLocation(), e.what());
        }
    }
}

void Ipv4NetworkConfigurator::resolveInterfaceAndGateway(Node *node, const char *interfaceAttr, const char *gatewayAttr,
        NetworkInterface *& outIE, Ipv4Address& outGateway, Topology& topology)
{
    // resolve interface name
    if (opp_isempty(interfaceAttr)) {
        outIE = nullptr;
    }
    else {
        outIE = node->interfaceTable->findInterfaceByName(interfaceAttr);
        if (!outIE)
            throw cRuntimeError("Host/router %s has no interface named \"%s\"",
                    node->module->getFullPath().c_str(), interfaceAttr);
    }

    // if gateway is not specified, we are done
    if (opp_isempty(gatewayAttr) || !strcmp(gatewayAttr, "*")) {
        outGateway = Ipv4Address();
        return; // outInterface also already done -- we're done
    }

    ASSERT(!opp_isempty(gatewayAttr)); // see "if" above

    // check syntax of gatewayAttr, and obtain an initial value
    outGateway = resolve(gatewayAttr, L3AddressResolver::ADDR_IPv4).toIpv4();

    Ipv4Address gatewayAddressOnCommonLink;

    if (!outIE) {
        // interface is not specified explicitly -- we must deduce it from the gateway.
        // It is expected that the gateway is on the same link with the configured node,
        // and then we pick the interface which connects to that link.

        // loop through all links, and find the one that contains both the
        // configured node and the gateway
        for (auto& linkInfo : topology.linkInfos) {
            InterfaceInfo *gatewayInterfaceOnLink = findInterfaceOnLinkByNodeAddress(linkInfo, outGateway);
            if (gatewayInterfaceOnLink) {
                InterfaceInfo *nodeInterfaceOnLink = findInterfaceOnLinkByNode(linkInfo, node->module);
                if (nodeInterfaceOnLink) {
                    outIE = nodeInterfaceOnLink->networkInterface;
                    gatewayAddressOnCommonLink = gatewayInterfaceOnLink->getAddress();
                    break;
                }
            }
        }
        if (!outIE)
            throw cRuntimeError("Host/router %s has no interface towards \"%s\"",
                    node->module->getFullPath().c_str(), gatewayAttr);
    }

    // Now we have both the interface and the gateway. Still, we may need to modify
    // the gateway address by picking the address of a different interface of the gateway --
    // the address of the interface which is towards the configured node (i.e. on the same link)
    //
    // gatewayAttr may be an IP address, or a module name, or modulename+interfacename
    // in a syntax accepted by L3AddressResolver. If the gatewayAttr is a concrete IP address
    // or contains a gateway interface name (L3AddressResolver accepts it after a "/"), we're done
    if (Ipv4Address::isWellFormed(gatewayAttr) || strchr(gatewayAttr, '/') != nullptr)
        return;

    // At this point, gatewayAttr must be a modulename string, so we can freely pick the
    // interface that's towards the configured node
    if (!gatewayAddressOnCommonLink.isUnspecified())
        outGateway = gatewayAddressOnCommonLink;
    else {
        // find the gateway interface that's on the same link as outIE

        // first, find which link outIE is on...
        LinkInfo *linkInfo = findLinkOfInterface(topology, outIE);

        // then find which gateway interface is on that link
        InterfaceInfo *gatewayInterface = findInterfaceOnLinkByNodeAddress(linkInfo, outGateway);
        if (gatewayInterface)
            outGateway = gatewayInterface->getAddress();
    }
}

Ipv4NetworkConfigurator::InterfaceInfo *Ipv4NetworkConfigurator::findInterfaceOnLinkByNode(LinkInfo *linkInfo, cModule *node)
{
    for (auto& element : linkInfo->interfaceInfos) {
        InterfaceInfo *interfaceInfo = static_cast<InterfaceInfo *>(element);
        if (interfaceInfo->networkInterface->getInterfaceTable()->getHostModule() == node)
            return interfaceInfo;
    }
    return nullptr;
}

Ipv4NetworkConfigurator::InterfaceInfo *Ipv4NetworkConfigurator::findInterfaceOnLinkByNodeAddress(LinkInfo *linkInfo, Ipv4Address address)
{
    for (auto& element : linkInfo->interfaceInfos) {
        // if the interface has this address, found
        InterfaceInfo *interfaceInfo = static_cast<InterfaceInfo *>(element);
        if (interfaceInfo->address == address.getInt())
            return interfaceInfo;

        // if some other interface of the same node has the address, we accept that too
        L3NetworkConfiguratorBase::Node *node = interfaceInfo->node;
        for (auto& it : node->interfaceInfos)
            if (static_cast<InterfaceInfo *>(it)->getAddress() == address)
                return interfaceInfo;

    }
    return nullptr;
}

Ipv4NetworkConfigurator::LinkInfo *Ipv4NetworkConfigurator::findLinkOfInterface(Topology& topology, NetworkInterface *ie)
{
    for (auto& linkInfo : topology.linkInfos) {
        for (size_t j = 0; j < linkInfo->interfaceInfos.size(); j++)
            if (linkInfo->interfaceInfos[j]->networkInterface == ie)
                return linkInfo;
    }
    return nullptr;
}

IRoutingTable *Ipv4NetworkConfigurator::findRoutingTable(L3NetworkConfiguratorBase::Node *node)
{
//	return L3AddressResolver().findIpv4RoutingTableOf(node->module);
	IRoutingTable * rt;
	rt = L3AddressResolver().findIpv4RoutingTableOf(node->module);
	if (!rt) {
		if (nodeModuleId2psmNetCfgData.count(node->getModuleId()) > 0) {
			rt = nodeModuleId2psmNetCfgData[node->getModuleId()]->getRoutingTable();
			assert(nodeModuleId2psmNetCfgData[node->getModuleId()]->getHaveRoutingTable());
		}
	}
    return rt;
}


bool Ipv4NetworkConfigurator::haveRoutingTable(omnetpp::cModule *from) {
	omnetpp::cModule *nodeModule = findContainingNode(from);
	if (nodeModule) {
		return nodeModule->findModuleByPath(".ipv4.routingTable") == nullptr ? false : true ;
	} else {
		return false;
	}
}

bool Ipv4NetworkConfigurator::containsRoute(const std::vector<Ipv4Route *>& routes, Ipv4Route *route)
{
    for (auto& rt : routes)
        if (*rt == *route)
            return true;
    return false;
}

void Ipv4NetworkConfigurator::addStaticRoutes(Topology& topology, cXMLElement *autorouteElement)
{EV_INFO<<"Ipv4NetworkConfigurator::addStaticRoutes(Topology& topology, cXMLElement *autorouteElement)"<<endl;
    long addStaticRoutesStartTime = clock();
    // set node weights
    const char *metric = autorouteElement->getAttribute("metric");
    if (metric == nullptr)
        metric = "hopCount";
    cXMLElement defaultNodeElement("node", "", nullptr);
    cXMLElementList nodeElements = autorouteElement->getChildrenByTagName("node");
    for (int i = 0; i < topology.getNumNodes(); i++) {
        cXMLElement *selectedNodeElement = &defaultNodeElement;
        Node *node = (Node *)topology.getNode(i);
        for (auto& nodeElement : nodeElements) {
            const char *hosts = nodeElement->getAttribute("hosts");
            if (hosts == nullptr)
                hosts = "**";
            Matcher nodeHostsMatcher(hosts);
            std::string hostFullPath = node->module->getFullPath();
            std::string hostShortenedFullPath = hostFullPath.substr(hostFullPath.find('.') + 1);
            if (nodeHostsMatcher.matchesAny() || nodeHostsMatcher.matches(hostShortenedFullPath.c_str()) || nodeHostsMatcher.matches(hostFullPath.c_str())) {
                selectedNodeElement = nodeElement;
                break;
            }
        }
        double weight = computeNodeWeight(node, metric, selectedNodeElement);
        EV_DEBUG << "Setting node weight, node = " << node->module->getFullPath() << ", weight = " << weight << endl;
        node->setWeight(weight);
    }
    // set link weights
    cXMLElement defaultLinkElement("link", "", nullptr);
    cXMLElementList linkElements = autorouteElement->getChildrenByTagName("link");
    for (int i = 0; i < topology.getNumNodes(); i++) {
        Node *node = (Node *)topology.getNode(i);
        for (int j = 0; j < node->getNumInLinks(); j++) {
            cXMLElement *selectedLinkElement = &defaultLinkElement;
            Link *link = (Link *)node->getLinkIn(j);
            for (auto& linkElement : linkElements) {
                const char *interfaces = linkElement->getAttribute("interfaces");
                if (interfaces == nullptr)
                    interfaces = "**";
                Matcher linkInterfaceMatcher(interfaces);
                std::string sourceFullPath = link->sourceInterfaceInfo->getFullPath();
                std::string sourceShortenedFullPath = sourceFullPath.substr(sourceFullPath.find('.') + 1);
                std::string destinationFullPath = link->destinationInterfaceInfo->getFullPath();
                std::string destinationShortenedFullPath = destinationFullPath.substr(destinationFullPath.find('.') + 1);
                if (linkInterfaceMatcher.matchesAny() ||
                    linkInterfaceMatcher.matches(sourceFullPath.c_str()) || linkInterfaceMatcher.matches(sourceShortenedFullPath.c_str()) ||
                    linkInterfaceMatcher.matches(destinationFullPath.c_str()) || linkInterfaceMatcher.matches(destinationShortenedFullPath.c_str()))
                {
                    selectedLinkElement = linkElement;
                    break;
                }
            }
            double weight = computeLinkWeight(link, metric, selectedLinkElement);
            EV_DEBUG << "Setting link weight, link = " << link << ", weight = " << weight << endl;
            link->setWeight(weight);
        }
    }
    // add static routes for all routing tables
    const char *sourceHosts = autorouteElement->getAttribute("sourceHosts");
    if (sourceHosts == nullptr)
        sourceHosts = "**";
    const char *destinationInterfaces = autorouteElement->getAttribute("destinationInterfaces");
    if (destinationInterfaces == nullptr)
        destinationInterfaces = "**";
    Matcher sourceHostsMatcher(sourceHosts);
    Matcher destinationInterfacesMatcher(destinationInterfaces);//cout << this->getFullPath() << "addStaticRoutes before traverse time : " << (static_cast<double>(clock() - addStaticRoutesStartTime) / CLOCKS_PER_SEC) << "s" << endl;
    
    int id = getSimulation()->getEnvir()->getParsimProcId();
    for (int i = 0; i < topology.getNumNodes(); i++) {
        Node *sourceNode = (Node *)topology.getNode(i);
        int ModId = sourceNode->module->getId();
        if(!enParsim||find(cur_lp_nodeId[id].begin(),cur_lp_nodeId[id].end(),ModId)!=cur_lp_nodeId[id].end()){
            std::string hostFullPath = sourceNode->module->getFullPath();EV_INFO<<"node = "<<hostFullPath<<endl;
            std::string hostShortenedFullPath = hostFullPath.substr(hostFullPath.find('.') + 1);
            if (!sourceHostsMatcher.matchesAny() && !sourceHostsMatcher.matches(hostShortenedFullPath.c_str()) && !sourceHostsMatcher.matches(hostFullPath.c_str()))
                continue;
            if (isBridgeNode(sourceNode))
                continue;
            // calculate shortest paths from everywhere to sourceNode
            // we are going to use the paths in reverse direction (assuming all links are bidirectional)
            topology.calculateWeightedSingleShortestPathsTo(sourceNode);//EV_INFO<<"addDefaultRoutesParameter = "<<addDefaultRoutesParameter<<", sourceNode->interfaceInfos.size() = "<<sourceNode->interfaceInfos.size()<<", sourceNode->interfaceInfos[0]->linkInfo->gatewayInterfaceInfo = "<<sourceNode->interfaceInfos[0]->linkInfo->gatewayInterfaceInfo<<", sourceNode->interfaceInfos[0]->addDefaultRoute = "<<sourceNode->interfaceInfos[0]->addDefaultRoute<<endl;
            // check if adding the default routes would be ok (this is an optimization)
            if (addDefaultRoutesParameter && sourceNode->interfaceInfos.size() == 1 && sourceNode->interfaceInfos[0]->linkInfo->gatewayInterfaceInfo && sourceNode->interfaceInfos[0]->addDefaultRoute) {EV_INFO<<"Ipv4NetworkConfigurator.cc: line 1363"<<endl;
                InterfaceInfo *sourceInterfaceInfo = static_cast<InterfaceInfo *>(sourceNode->interfaceInfos[0]);
                NetworkInterface *sourceNetworkInterface = sourceInterfaceInfo->networkInterface;
                InterfaceInfo *gatewayInterfaceInfo = static_cast<InterfaceInfo *>(sourceInterfaceInfo->linkInfo->gatewayInterfaceInfo);
        //            NetworkInterface *gatewayNetworkInterface = gatewayInterfaceInfo->networkInterface;

                if (addDirectRoutesParameter) {EV_INFO<<"Ipv4NetworkConfigurator.cc: line 1369"<<endl;
                    // add a network route for the local network using ARP
                    Ipv4Route *route = new Ipv4Route();EV_INFO<<"source IP = "<<sourceInterfaceInfo->getAddress()<<", netmask = "<<sourceInterfaceInfo->getNetmask()<<endl;
                    route->setDestination(sourceInterfaceInfo->getAddress().doAnd(sourceInterfaceInfo->getNetmask()));
                    route->setGateway(Ipv4Address::UNSPECIFIED_ADDRESS);
                    route->setNetmask(sourceInterfaceInfo->getNetmask());
                    route->setInterface(sourceNetworkInterface);
                    route->setSourceType(Ipv4Route::MANUAL);
                    sourceNode->staticRoutes.push_back(route);EV_INFO<<route->str()<<endl;
        //                std::cout << "###  staticRoutes1" << ", Destination:" << route->getDestination().str() << ", Netmask:" << route->getNetmask().str() << std::endl;
                }

                // add a default route towards the only one gateway
                Ipv4Route *route = new Ipv4Route();
                Ipv4Address gateway = gatewayInterfaceInfo->getAddress();
                route->setDestination(Ipv4Address::UNSPECIFIED_ADDRESS);
                route->setNetmask(Ipv4Address::UNSPECIFIED_ADDRESS);
                route->setGateway(gateway);
                route->setInterface(sourceNetworkInterface);
                route->setSourceType(Ipv4Route::MANUAL);
                sourceNode->staticRoutes.push_back(route);EV_INFO<<route->str()<<endl;
        //            std::cout << "###  staticRoutes2" << ", Destination:" << route->getDestination().str() << ", Netmask:" << route->getNetmask().str() << std::endl;

                // skip building and optimizing the whole routing table
                EV_DEBUG << "Adding default routes to " << sourceNode->getModule()->getFullPath() << ", node has only one (non-loopback) interface\n";
            }
            else {EV_INFO<<"Ipv4NetworkConfigurator.cc: line 1393"<<endl;
                // add a route to all destinations in the network
                for (int j = 0; j < topology.getNumNodes(); j++) {
                    // extract destination
                    Node *destinationNode = (Node *)topology.getNode(j);
                    if (sourceNode == destinationNode)
                        continue;
                    if (destinationNode->getNumPaths() == 0)
                        continue;
                    if (isBridgeNode(destinationNode))
                        continue;
                    if (std::isinf(destinationNode->getDistanceToTarget()))
                        continue;

                    //added by HiNA
                    if(ecmp){
                        for(auto i=0;i<destinationNode->getNumPaths();i++){
                            Link *link = (Link *)destinationNode->getPath(i);
                            EV<<"outpath["<<i<<"] source = "<<link->sourceInterfaceInfo->networkInterface->getInterfaceFullPath()<<", dest = "<<link->destinationInterfaceInfo->networkInterface->getInterfaceFullPath()<<endl;
                        }
                        std::list<Node *> newnode;
                        std::vector<Node *> oldnode;
                        std::vector<Link *> linkvec;
                        std::map<Link *, InterfaceInfo *> nexthopmap;
                        newnode.push_back(destinationNode);
                        while(!newnode.empty()){
                            Node *node=newnode.front();
                            oldnode.push_back(node);
                            newnode.pop_front();
                            for(auto i=0;i<node->getNumPaths();i++){
                                Node *nextnode=(Node *)node->getPath(i)->getLinkOutRemoteNode();
                                Link *link = (Link *)node->getPath(i);
                                if(nextnode==sourceNode){
                                    linkvec.push_back(link);
                                    if (node != sourceNode && !isBridgeNode(node) && link->sourceInterfaceInfo)
                                        nexthopmap[link]=static_cast<InterfaceInfo *>(link->sourceInterfaceInfo);
                                }else if(!contains(oldnode,nextnode)){
                                    newnode.push_back(nextnode);
                                }
                            }
                        }
                        for(auto link:linkvec){
                            if (nexthopmap.find(link)->second && link->destinationInterfaceInfo && link->destinationInterfaceInfo->addStaticRoute) {
                                NetworkInterface *sourceNetworkInterface = link->destinationInterfaceInfo->networkInterface;EV<<"link source interface = "<<sourceNetworkInterface->getInterfaceFullPath()<<endl;
                                // add the same routes for all destination interfaces (IP packets are accepted from any interface at the destination)
                                for (size_t j = 0; j < destinationNode->interfaceInfos.size(); j++) {
                                    InterfaceInfo *destinationInterfaceInfo = static_cast<InterfaceInfo *>(destinationNode->interfaceInfos[j]);
                                    std::string destinationFullPath = destinationInterfaceInfo->networkInterface->getInterfaceFullPath();//EV_INFO<<"destinationFullPath = "<<destinationFullPath<<endl;
                                    std::string destinationShortenedFullPath = destinationFullPath.substr(destinationFullPath.find('.') + 1);EV_INFO<<"destination interface = "<<destinationShortenedFullPath<<endl;
                                    if (!destinationInterfacesMatcher.matchesAny() &&
                                        !destinationInterfacesMatcher.matches(destinationFullPath.c_str()) &&
                                        !destinationInterfacesMatcher.matches(destinationShortenedFullPath.c_str()))
                                        continue;
                                    NetworkInterface *destinationNetworkInterface = destinationInterfaceInfo->networkInterface;
                                    Ipv4Address destinationAddress = destinationInterfaceInfo->getAddress();
                                    Ipv4Address destinationNetmask = destinationInterfaceInfo->getNetmask();
                                    if (!destinationNetworkInterface->isLoopback() && !destinationAddress.isUnspecified()) {EV_INFO<<"Ipv4NetworkConfigurator.cc: line 1435"<<endl;
                                        Ipv4Route *route = new Ipv4Route();
                                        Ipv4Address gatewayAddress = nexthopmap.find(link)->second->getAddress();
                                        if (addSubnetRoutesParameter && destinationNode->interfaceInfos.size() == 1 && destinationNode->interfaceInfos[0]->linkInfo->gatewayInterfaceInfo
                                            && destinationNode->interfaceInfos[0]->addSubnetRoute)
                                        {
                                            ASSERT(!destinationAddress.doAnd(destinationNetmask).isUnspecified());
                                            route->setDestination(destinationAddress.doAnd(destinationNetmask));
                                            route->setNetmask(destinationNetmask);
                                        }
                                        else {
                                            route->setDestination(destinationAddress);
                                            route->setNetmask(Ipv4Address::ALLONES_ADDRESS);
                                        }
                                        route->setInterface(sourceNetworkInterface);
                                        if (gatewayAddress != destinationAddress)
                                            route->setGateway(gatewayAddress);
                                        route->setSourceType(Ipv4Route::MANUAL);
                                        if (containsRoute(sourceNode->staticRoutes, route))
                                            {delete route;EV_INFO<<"Ipv4NetworkConfigurator.cc: line 1469"<<endl;}
                                        else if (!addDirectRoutesParameter && route->getGateway().isUnspecified())
                                            {delete route;EV_INFO<<"Ipv4NetworkConfigurator.cc: line 1471"<<endl;}
                                        else {//EV_INFO<<"Ipv4NetworkConfigurator.cc: line 1457"<<endl;
                                            sourceNode->staticRoutes.push_back(route);EV_INFO<<route->str()<<endl;
                                        //    std::cout << "###  staticRoutes3" << ", Destination:" << route->getDestination() << ", Netmask:" << route->getNetmask() << std::endl;
                                        //    std::cout << "Adding route " << sourceNetworkInterface->getInterfaceFullPath() << " -> " << destinationNetworkInterface->getInterfaceFullPath()
                                        //    		<< ",destinationAddress:" << route->getDestination().str() << " ,destinationNetmask:" << route->getNetmask().str()
                                        // 			<< ",Gateway:" << route->getGateway().str() << std::endl;
                                            EV_DEBUG << "Adding route " << sourceNetworkInterface->getInterfaceFullPath() << " -> " << destinationNetworkInterface->getInterfaceFullPath() << " as " << route->str() << endl;
                                        }
                                    }
                                }
                            }
                        }
                    }//added by HiNA
                    else{
                        // determine next hop interface
                        // find next hop interface (the last IP interface on the path that is not in the source node)
                        Node *node = destinationNode;
                        Link *link = nullptr;
                        InterfaceInfo *nextHopInterfaceInfo = nullptr;
                        while (node != sourceNode) {
                            link = (Link *)node->getPath(0);
                            if (node != sourceNode && !isBridgeNode(node) && link->sourceInterfaceInfo)
                                nextHopInterfaceInfo = static_cast<InterfaceInfo *>(link->sourceInterfaceInfo);
                            node = (Node *)node->getPath(0)->getLinkOutRemoteNode();
                        }

                        // determine source interface
                        if (nextHopInterfaceInfo && link->destinationInterfaceInfo && link->destinationInterfaceInfo->addStaticRoute) {
                            NetworkInterface *sourceNetworkInterface = link->destinationInterfaceInfo->networkInterface;EV<<"link source = "<<link->destinationInterfaceInfo->node->module->getFullPath()<<", NetworkInterface = "<<sourceNetworkInterface->getInterfaceFullPath()<<endl;
                            // add the same routes for all destination interfaces (IP packets are accepted from any interface at the destination)
                            for (size_t j = 0; j < destinationNode->interfaceInfos.size(); j++) {
                                InterfaceInfo *destinationInterfaceInfo = static_cast<InterfaceInfo *>(destinationNode->interfaceInfos[j]);
                                std::string destinationFullPath = destinationInterfaceInfo->networkInterface->getInterfaceFullPath();EV_INFO<<"destinationFullPath = "<<destinationFullPath<<endl;
                                std::string destinationShortenedFullPath = destinationFullPath.substr(destinationFullPath.find('.') + 1);EV_INFO<<"destinationShortenedFullPath = "<<destinationShortenedFullPath<<endl;
                                if (!destinationInterfacesMatcher.matchesAny() &&
                                    !destinationInterfacesMatcher.matches(destinationFullPath.c_str()) &&
                                    !destinationInterfacesMatcher.matches(destinationShortenedFullPath.c_str()))
                                    continue;
                                NetworkInterface *destinationNetworkInterface = destinationInterfaceInfo->networkInterface;
                                Ipv4Address destinationAddress = destinationInterfaceInfo->getAddress();
                                Ipv4Address destinationNetmask = destinationInterfaceInfo->getNetmask();
                                if (!destinationNetworkInterface->isLoopback() && !destinationAddress.isUnspecified()) {EV_INFO<<"Ipv4NetworkConfigurator.cc: line 1502"<<endl;
                                    Ipv4Route *route = new Ipv4Route();
                                    Ipv4Address gatewayAddress = nextHopInterfaceInfo->getAddress();
                                    if (addSubnetRoutesParameter && destinationNode->interfaceInfos.size() == 1 && destinationNode->interfaceInfos[0]->linkInfo->gatewayInterfaceInfo
                                        && destinationNode->interfaceInfos[0]->addSubnetRoute)
                                    {
                                        ASSERT(!destinationAddress.doAnd(destinationNetmask).isUnspecified());
                                        route->setDestination(destinationAddress.doAnd(destinationNetmask));
                                        route->setNetmask(destinationNetmask);
                                    }
                                    else {
                                        route->setDestination(destinationAddress);
                                        route->setNetmask(Ipv4Address::ALLONES_ADDRESS);
                                    }
                                    route->setInterface(sourceNetworkInterface);
                                    if (gatewayAddress != destinationAddress)
                                        route->setGateway(gatewayAddress);
                                    route->setSourceType(Ipv4Route::MANUAL);
                                    if (containsRoute(sourceNode->staticRoutes, route))
                                        {delete route;EV_INFO<<"Ipv4NetworkConfigurator.cc: line 1521"<<endl;}
                                    else if (!addDirectRoutesParameter && route->getGateway().isUnspecified())
                                        {delete route;EV_INFO<<"Ipv4NetworkConfigurator.cc: line 1523"<<endl;}
                                    else {EV_INFO<<"Ipv4NetworkConfigurator.cc: line 1524"<<endl;
                                        sourceNode->staticRoutes.push_back(route);EV_INFO<<route->str()<<endl;
                                        EV_DEBUG << "Adding route " << sourceNetworkInterface->getInterfaceFullPath() << " -> " << destinationNetworkInterface->getInterfaceFullPath() << " as " << route->str() << endl;
                                    }
                                }
                            }
                        }
                    }
                }

                // optimize routing table to save memory and increase lookup performance
                if (optimizeRoutesParameter) {
                    std::cout << "@@@@" << this->getFullPath() << ", optimizeRoutes start, pid:" << this->getSimulation()->getActiveEnvir()->getParsimProcId() << std::endl;
                    optimizeRoutes(sourceNode->staticRoutes);
                    std::cout << "@@@@" << this->getFullPath() << ", optimizeRoutes end, pid:" << this->getSimulation()->getActiveEnvir()->getParsimProcId()  << std::endl;
                }
            }
        }

    }
}

/**
 * Returns true if the two routes are the same except their address prefix and netmask.
 * If it returns true we say that the routes have the same color.
 */
bool Ipv4NetworkConfigurator::routesHaveSameColor(Ipv4Route *route1, Ipv4Route *route2)
{
    return route1->getSourceType() == route2->getSourceType() && route1->getMetric() == route2->getMetric() &&
           route1->getGateway() == route2->getGateway() && route1->getInterface() == route2->getInterface();
}

/**
 * Returns the index of the first route that has the same color.
 */
int Ipv4NetworkConfigurator::findRouteIndexWithSameColor(const std::vector<Ipv4Route *>& routes, Ipv4Route *route)
{
    for (size_t i = 0; i < routes.size(); i++)
        if (routesHaveSameColor(routes[i], route))
            return i;

    return -1;
}

/**
 * Returns true if swapping two ADJACENT routes in the routing table does not change the table's meaning.
 */
bool Ipv4NetworkConfigurator::routesCanBeSwapped(RouteInfo *routeInfo1, RouteInfo *routeInfo2)
{
    if (routeInfo1->color == routeInfo2->color)
        return true; // these two routes send the packet in the same direction (same gw/iface), doesn't matter which one we use -> can be swapped
    else {
        // unrelated routes can also be swapped
        uint32_t netmask = routeInfo1->netmask & routeInfo2->netmask;
        return (routeInfo1->destination & netmask) != (routeInfo2->destination & netmask);
    }
}

/**
 * Returns true if the routes can be neighbors by repeatedly swapping routes
 * in the routing table without changing their meaning.
 */
bool Ipv4NetworkConfigurator::routesCanBeNeighbors(const std::vector<RouteInfo *>& routeInfos, int i, int j)
{
    int begin = std::min(i, j);
    int end = std::max(i, j);
    Ipv4NetworkConfigurator::RouteInfo *beginRouteInfo = routeInfos.at(begin);
    for (int index = begin + 1; index < end; index++)
        if (!routesCanBeSwapped(beginRouteInfo, routeInfos.at(index)))
            return false;

    return true;
}

/**
 * Returns true if the original route is interrupted by any of the routes in
 * the routing table between begin and end.
 */
bool Ipv4NetworkConfigurator::interruptsOriginalRoute(const RoutingTableInfo& routingTableInfo, int begin, int end, RouteInfo *originalRouteInfo)
{
    Ipv4NetworkConfigurator::RouteInfo *matchingRouteInfo = routingTableInfo.findBestMatchingRouteInfo(originalRouteInfo->destination, begin, end);
    return matchingRouteInfo && matchingRouteInfo->color != originalRouteInfo->color;
}

/**
 * Returns true if any of the original routes is interrupted by any of the
 * routes in the routing table between begin and end.
 */
bool Ipv4NetworkConfigurator::interruptsAnyOriginalRoute(const RoutingTableInfo& routingTableInfo, int begin, int end, const std::vector<RouteInfo *>& originalRouteInfos)
{
    if (begin < end)
        for (auto& originalRouteInfo : originalRouteInfos)
            if (interruptsOriginalRoute(routingTableInfo, begin, end, originalRouteInfo))
                return true;

    return false;
}

/**
 * Returns true if any of the original routes attached to the routes in the
 * routing table below index are interrupted by the route at index.
 */
bool Ipv4NetworkConfigurator::interruptsSubsequentOriginalRoutes(const RoutingTableInfo& routingTableInfo, int index)
{
    for (size_t i = index + 1; i < routingTableInfo.routeInfos.size(); i++) {
        Ipv4NetworkConfigurator::RouteInfo *routeInfo = routingTableInfo.routeInfos.at(i);
        if (interruptsAnyOriginalRoute(routingTableInfo, index, index + 1, routeInfo->originalRouteInfos))
            return true;
    }
    return false;
}

/**
 * Asserts that all original routes are still routed the same way as by the original routing table.
 */
void Ipv4NetworkConfigurator::checkOriginalRoutes(const RoutingTableInfo& routingTableInfo, const RoutingTableInfo& originalRoutingTableInfo)
{
    // assert that all original routes are routed with the same color
    for (auto& originalRouteInfo : originalRoutingTableInfo.routeInfos) {
        Ipv4NetworkConfigurator::RouteInfo *matchingRouteInfo = routingTableInfo.findBestMatchingRouteInfo(originalRouteInfo->destination);
        Ipv4NetworkConfigurator::RouteInfo *matchingOriginalRouteInfo = originalRoutingTableInfo.findBestMatchingRouteInfo(originalRouteInfo->destination);
        ASSERT(matchingRouteInfo && matchingRouteInfo->color == matchingOriginalRouteInfo->color);
    }
}

/**
 * Returns the longest shared address prefix and netmask by iterating through bits from left to right.
 */
void Ipv4NetworkConfigurator::findLongestCommonDestinationPrefix(uint32_t destination1, uint32_t netmask1, uint32_t destination2, uint32_t netmask2, uint32_t& destinationOut, uint32_t& netmaskOut)
{
    netmaskOut = 0;
    destinationOut = 0;
    for (int bitIndex = 31; bitIndex >= 0; bitIndex--) {
        uint32_t mask = 1 << bitIndex;
        if ((destination1 & mask) == (destination2 & mask) &&
            (netmask1 & mask) != 0 && (netmask2 & mask) != 0)
        {
            netmaskOut |= mask;
            destinationOut |= destination1 & mask;
        }
        else
            break;
    }
}

/**
 * Adds all of the original routes to the matching optimized routes between begin and end.
 */
void Ipv4NetworkConfigurator::addOriginalRouteInfos(RoutingTableInfo& routingTableInfo, int begin, int end, const std::vector<RouteInfo *>& originalRouteInfos)
{
    for (auto& originalRouteInfo : originalRouteInfos) {
        Ipv4NetworkConfigurator::RouteInfo *matchingRouteInfo = routingTableInfo.findBestMatchingRouteInfo(originalRouteInfo->destination, begin, end);
        ASSERT(matchingRouteInfo && matchingRouteInfo->color == originalRouteInfo->color);
        matchingRouteInfo->originalRouteInfos.push_back(originalRouteInfo);
    }
}

/**
 * Try to merge two routes that have the same color and could be neighbours in table
 * without changing the table's meaning. There are two merge opportunities:
 * (1) one route's network contains the other one (then the second can be dropped),
 * and (2) use a shorter common prefix that covers both (this is only possible
 * if this doesn't interfere with existing routes in the table).
 * Returns true if the two routes have been merged, otherwise returns false.
 */
bool Ipv4NetworkConfigurator::tryToMergeTwoRoutes(RoutingTableInfo& routingTableInfo, int i, int j, RouteInfo *routeInfoI, RouteInfo *routeInfoJ)
{
    // determine longest shared address prefix and netmask by iterating through bits from left to right
    uint32_t netmask;
    uint32_t destination;
    findLongestCommonDestinationPrefix(routeInfoI->destination, routeInfoI->netmask, routeInfoJ->destination, routeInfoJ->netmask, destination, netmask);

    // create the merged route
    ASSERT(routeInfoI->color == routeInfoJ->color);
    RouteInfo *mergedRouteInfo = new RouteInfo(routeInfoI->color, destination, netmask);
    routeInfoI->enabled = false;
    routeInfoJ->enabled = false;
    int m = routingTableInfo.addRouteInfo(mergedRouteInfo);
    ASSERT(m > i && m > j);

    // check if all the original routes are still routed the same way by the optimized routing table.
    // check optimization: instead of checking all the original routes, check only those which can go wrong due to the merge.
    // (assuming the previous configuration was correct)
    // - the original routes on I and J are going to be routed by M after the merge, so check if the routes in between don't interrupt them
    // - the original routes following M can be accidentally overridden by M (being larger than the sum of I and J), so verify that M does not interrupt them
    // note that the condition is not symmetric because I follows J so it requires fewer checks and we do use that.
    if (!interruptsAnyOriginalRoute(routingTableInfo, j + 1, i, routeInfoJ->originalRouteInfos) && // check that original routes on J are not interrupted between J and I
        !interruptsAnyOriginalRoute(routingTableInfo, i + 1, m, routeInfoJ->originalRouteInfos) && // check that original routes on J are not interrupted between I and M
        !interruptsAnyOriginalRoute(routingTableInfo, i + 1, m, routeInfoI->originalRouteInfos) && // check that original routes on I are not interrupted between I and M
        !interruptsSubsequentOriginalRoutes(routingTableInfo, m)) // check that the original routes after M are not interrupted by M
    {
        // now we know that the merge does not conflict with any route in the routing table.
        // the next thing to do is to maintain the original routes attached to the optimized ones.
        // move original routes from the to be deleted I route to the capturing routes.
        addOriginalRouteInfos(routingTableInfo, i + 1, m + 1, routeInfoI->originalRouteInfos);

        // move original routes from the to be deleted J route to the capturing routes.
        addOriginalRouteInfos(routingTableInfo, j + 1, m + 1, routeInfoJ->originalRouteInfos);

        // move original routes from the routes following the merged one if necessary.
        for (int k = m + 1; k < (int)routingTableInfo.routeInfos.size(); k++) {
            Ipv4NetworkConfigurator::RouteInfo *followingRouteInfo = routingTableInfo.routeInfos.at(k);
            for (int l = 0; l < (int)followingRouteInfo->originalRouteInfos.size(); l++) {
                Ipv4NetworkConfigurator::RouteInfo *originalRouteInfo = followingRouteInfo->originalRouteInfos.at(l);
                if (!((originalRouteInfo->destination ^ mergedRouteInfo->destination) & mergedRouteInfo->netmask)) {
                    followingRouteInfo->originalRouteInfos.erase(followingRouteInfo->originalRouteInfos.begin() + l);
                    ASSERT(mergedRouteInfo->color == originalRouteInfo->color);
                    mergedRouteInfo->originalRouteInfos.push_back(originalRouteInfo);
                    l--;
                }
            }
        }
        routingTableInfo.removeRouteInfo(routeInfoI);
        routingTableInfo.removeRouteInfo(routeInfoJ);
#ifndef NDEBUG
//        checkOriginalRoutes(routingTableInfo, originalRoutingTableInfos);
#endif // ifndef NDEBUG
        delete routeInfoI;
        delete routeInfoJ;
        return true;
    }
    else {
        // merge failed; restore original state
        routeInfoI->enabled = true;
        routeInfoJ->enabled = true;
        routingTableInfo.removeRouteInfo(mergedRouteInfo);
        delete mergedRouteInfo;
        return false;
    }
}

/**
 * Iteratively checks if any two routes can be aggressively merged without changing the meaning of all original routes.
 * The merged route will have the longest shared address prefix and netmask with the two merged routes.
 * This optimization might change the meaning of the routing table in that it will route packets that it did not route before.
 * Nevertheless, any packet routed by the original routing table will still be routed the same way by the optimized routing table.
 * Returns true if two routes has been merged, otherwise returns false.
 */
bool Ipv4NetworkConfigurator::tryToMergeAnyTwoRoutes(RoutingTableInfo& routingTableInfo)
{
    for (int i = 0; i < (int)routingTableInfo.routeInfos.size(); i++) {
        Ipv4NetworkConfigurator::RouteInfo *routeInfoI = routingTableInfo.routeInfos.at(i);

        // iterate backward so that we try to merge routes having longer netmasks first.
        // this results in smaller changes and allows more symmetric optimization.
        for (int j = i - 1; j >= 0; j--) {
            Ipv4NetworkConfigurator::RouteInfo *routeInfoJ = routingTableInfo.routeInfos.at(j);

            // we can only merge neighbor routes having the same color
            if (routeInfoI->color == routeInfoJ->color && routesCanBeNeighbors(routingTableInfo.routeInfos, i, j)) {
                // it is worth to actually try to merge them
                if (tryToMergeTwoRoutes(routingTableInfo, i, j, routeInfoI, routeInfoJ))
                    return true;
            }
        }
    }
    return false;
}

void Ipv4NetworkConfigurator::optimizeRoutes(std::vector<Ipv4Route *>& originalRoutes)
{
    // The basic idea: if two routes "do the same" (same output interface, gateway, etc) and
    // match "similar" addresses, one can try to move them to be neighbors in the table and
    // replace them with a single route which contains their longest common prefix as address
    // prefix -- provided that this operation doesn't affect the meaning of the routing table
    // for "existing" addresses. (We don't care about changing the routing for addresses that
    // we know don't occur in our currently configured network.) We can repeatedly merge routes
    // in this way until it's not possible any more. Of course, the result also depends on
    // which pairs of routes we merge, and in which order.

    // STEP 1.
    // instead of working with Ipv4 routes we transform them into the internal representation of the optimizer.
    // routes are classified based on their action (gateway, interface, type, source, metric, etc.) and a color is assigned to them.
    RoutingTableInfo routingTableInfo;
    std::vector<Ipv4Route *> colorToRoute; // a mapping from color to route action (interface, gateway, metric, etc.)
    RoutingTableInfo originalRoutingTableInfo; // a copy of the original routes in the optimizer's format

    // build colorToRouteColor, originalRoutingTableInfo and initial routeInfos in routingTableInfo
    for (auto& originalRoute : originalRoutes) {
        int color = findRouteIndexWithSameColor(colorToRoute, originalRoute);
        if (color == -1) {
            color = colorToRoute.size();
            colorToRoute.push_back(originalRoute);
        }

        // create original route and determine its color
        RouteInfo *originalRouteInfo = new RouteInfo(color, originalRoute->getDestination().getInt(), originalRoute->getNetmask().getInt());
        originalRoutingTableInfo.addRouteInfo(originalRouteInfo);

        // create a copy of the original route that can be destructively optimized later
        RouteInfo *optimizedRouteInfo = new RouteInfo(*originalRouteInfo);
        optimizedRouteInfo->originalRouteInfos.push_back(originalRouteInfo);
        routingTableInfo.addRouteInfo(optimizedRouteInfo);
    }

#ifndef NDEBUG
    checkOriginalRoutes(routingTableInfo, originalRoutingTableInfo);
#endif // ifndef NDEBUG

    // STEP 2.
    // from now on we are only working with the internal data structures called RouteInfo and RoutingTableInfo.
    // the main optimizer loop runs until it cannot merge any two routes.
    // std::cout << "@@@@" << this->getFullPath() << "tryToMergeAnyTwoRoutes start" << std::endl;
    while (tryToMergeAnyTwoRoutes(routingTableInfo))
        ;
    // std::cout << "@@@@" << this->getFullPath() << "tryToMergeAnyTwoRoutes end" << std::endl;

#ifndef NDEBUG
    checkOriginalRoutes(routingTableInfo, originalRoutingTableInfo);
#endif // ifndef NDEBUG

    for (auto rti : originalRoutingTableInfo.routeInfos)
        delete rti;
    originalRoutingTableInfo.routeInfos.clear();

    // STEP 3.
    // convert the optimized routes to new optimized Ipv4 routes based on the saved colors
    std::vector<Ipv4Route *> optimizedRoutes;
    for (auto& routeInfo : routingTableInfo.routeInfos) {
        Ipv4Route *routeColor = colorToRoute[routeInfo->color];
        Ipv4Route *optimizedRoute = new Ipv4Route();
        optimizedRoute->setDestination(Ipv4Address(routeInfo->destination));
        optimizedRoute->setNetmask(Ipv4Address(routeInfo->netmask));
        optimizedRoute->setInterface(routeColor->getInterface());
        optimizedRoute->setGateway(routeColor->getGateway());
        optimizedRoute->setSourceType(routeColor->getSourceType());
        optimizedRoute->setMetric(routeColor->getMetric());
        optimizedRoutes.push_back(optimizedRoute);
//        std::cout << "###  staticRoutes5" << ", Destination:" << optimizedRoute->getDestination() << ", Netmask:" << optimizedRoute->getNetmask() << std::endl;
        delete routeInfo;
    }

    // delete original routes, we destructively modify them
    for (auto& originalRoute : originalRoutes)
        delete originalRoute;

    // copy optimized routes to original routes and return
    originalRoutes = optimizedRoutes;
}

bool Ipv4NetworkConfigurator::getInterfaceIpv4Address(L3Address& ret, NetworkInterface *networkInterface, bool netmask)
{
	nmIdPair pkey = {networkInterface->getInterfaceTable()->getHostModule()->getId(), networkInterface->getId()};
    // std::cout<<"Ipv4NetworkConfigurator::getInterfaceIpv4Address(L3Address& ret, NetworkInterface *networkInterface, bool netmask), "
    // <<"hostmoduleId = "<<networkInterface->getInterfaceTable()->getHostModule()->getId()<<", interfaceid = "<<networkInterface->getId()<<std::endl;
//	auto it = topology.interfaceInfos.find(networkInterface->getId());
	auto it = topology.interfaceInfos.find(pkey);
    if (it == topology.interfaceInfos.end()){std::cout<<networkInterface->getInterfaceFullPath().c_str()<<" not found in topology.interfaceInfos"<<std::endl;
        return false;
    }   
    else {
        InterfaceInfo *interfaceInfo = static_cast<InterfaceInfo *>(it->second);
        // std::cout<<networkInterface->getInterfaceFullPath().c_str()<<" found in topology.interfaceinfos, configure = "<<interfaceInfo->configure<<", addr = "<<interfaceInfo->getAddress()<<std::endl;
        if (interfaceInfo->configure)
            ret = netmask ? interfaceInfo->getNetmask() : interfaceInfo->getAddress();
        return interfaceInfo->configure;
    }
}

} // namespace inet

