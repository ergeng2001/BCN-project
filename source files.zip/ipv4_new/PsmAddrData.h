//statment-------------------------------------------------------------------------------------------------------------------------------------------
// HiNA High-performance Network and Architecture Laboratory belongs to NUDT Computer Research Institute. This Lab mainly responsible for ...
// This Project Develop a simulation software prototype supporting the full stack collaborative design of high-speed interconnection networks,
// and provide an accurate experimental environment and quantitative evaluation platform for the development of software
// and hardware of high-performance interconnection and data center networks in the future
// The Leader Dezun Dong, researcher of NDUT, and head of the High Performance Network and Architecture (HiNA) Laboratory,
// is responsible for the design, verification and performance optimization of large-scale high-performance interconnection networks.

// Copyright (c) 2011-2023, HINA High-performance Network and Architecture Laboratory

// All rights reserved.

// Redistribution and use in source and binary forms, with or without modification,
// are permitted provided that the following conditions are met:

//     * If all versions and documents of the project need to be transmitted to someone,
//       relevant information must be reported to the laboratory and approved.

//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.

//     * Redistributions in binary form must reproduce the above
//       copyright notice, this list of conditions and the following
//       disclaimer in the documentation and/or other materials provided
//       with the distribution.

//     * Neither the name of HiNA Group nor the names of its
//       contributors may be used to endorse or promote products derived
//       from this software without specific prior written permission.

// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

// Questions? Contact dong@nudt.edu.cn
//--------------------------------------------------------------------------------------------------------------------------------------------

#ifndef PSMADDRDATA_H_
#define PSMADDRDATA_H_

#include <omnetpp/cownedobject.h>
#include <models/inet/networklayer/contract/ipv4/Ipv4Address_m.h>

class psmAddrDataStruct : public omnetpp::cObject
{
private:
    int nodeId;
    int modId;
    uint32_t netmask;
    uint32_t Addr;

    void copy(const psmAddrDataStruct& other);
public:
	/**
	 *  Constructor
	 */
	psmAddrDataStruct();
    psmAddrDataStruct(int nodeId, int modId, uint32_t Addr, uint32_t netmask);
	/**
	 *  Destructor
	 */
    virtual ~psmAddrDataStruct();

    int getNodeId();
    int getModId();
    uint32_t getAddr();
    uint32_t getNetmask();

    psmAddrDataStruct& operator=(const psmAddrDataStruct& other);
    virtual psmAddrDataStruct *dup() const override {return new psmAddrDataStruct(*this);}
    virtual void parsimPack(omnetpp::cCommBuffer *buffer) const;
    virtual void parsimUnpack(omnetpp::cCommBuffer *buffer);
};

class psmAddrData : public omnetpp::cObject
{
private:
    size_t arraysize = 0;
    psmAddrDataStruct *data;

public:
    psmAddrData();
    virtual ~psmAddrData();

    virtual void setArraySize(size_t size);
    virtual size_t getArraySize() const;

    virtual psmAddrDataStruct getData(size_t k) const;
    virtual void setData(size_t k, psmAddrDataStruct *data);
    // virtual void removeData(size_t k);

    virtual void parsimPack(omnetpp::cCommBuffer *buffer) const;
    virtual void parsimUnpack(omnetpp::cCommBuffer *buffer);
};

#endif /* psmAddrData_H_ */


