
#include "models/inet/networklayer/configurator/ipv4/PsmAddrData.h"

#ifdef WITH_PARSIM
#include <omnetpp/ccommbuffer.h>
#endif

Register_Class(psmAddrDataStruct);

psmAddrDataStruct::psmAddrDataStruct(){

}

psmAddrDataStruct::psmAddrDataStruct(int nodeId, int modId, uint32_t Addr, uint32_t netmask){
    this->nodeId = nodeId;
    this->modId = modId;
    this->Addr = Addr;
    this->netmask = netmask;
}

psmAddrDataStruct::~psmAddrDataStruct(){

}

int psmAddrDataStruct::getNodeId()
{
    return nodeId;
}

int psmAddrDataStruct::getModId()
{
    return modId;
}

uint32_t psmAddrDataStruct::getAddr() {
	return Addr;
}

uint32_t psmAddrDataStruct::getNetmask() {
	return netmask;
}

psmAddrDataStruct& psmAddrDataStruct::operator=(const psmAddrDataStruct& other)
{
    if (this == &other) return *this;
    ::omnetpp::cObject::operator=(other);
    copy(other);
    return *this;
}

void psmAddrDataStruct::copy(const psmAddrDataStruct& other)
{
    this->nodeId = other.nodeId;
    this->modId = other.modId;
    this->Addr = other.Addr;
    this->netmask = other.netmask;
}

void psmAddrDataStruct::parsimPack(omnetpp::cCommBuffer *buffer) const
{
    buffer->pack(this->nodeId);
    buffer->pack(this->modId);
    buffer->pack(this->Addr);
    buffer->pack(this->netmask);
    // int unpacknodeId, unpackmodId,unpackAddr,unpack_netmask;
    // buffer->unpack(unpacknodeId);
    // buffer->unpack(unpackmodId);
    // buffer->unpack(unpackAddr);
    // buffer->unpack(unpack_netmask);std::cout<<"netmask = "<<netmask<<", unpack_netmask = "<<unpack_netmask<<std::endl;
    // buffer->pack(this->nodeId);
    // buffer->pack(this->modId);
    // buffer->pack(this->Addr);
    // buffer->pack(this->netmask);
}

void psmAddrDataStruct::parsimUnpack(omnetpp::cCommBuffer *buffer)
{  
    buffer->unpack(this->nodeId);
    buffer->unpack(this->modId);
    buffer->unpack(this->Addr);
    buffer->unpack(this->netmask);//std::cout<<"unpack_netmask = "<<this->netmask<<std::endl;
}

Register_Class(psmAddrData);

psmAddrData::psmAddrData(){

}

psmAddrData::~psmAddrData(){

}

void psmAddrData::setArraySize(size_t newSize){
    arraysize = newSize;
}

size_t psmAddrData::getArraySize() const{
    return arraysize;
}

psmAddrDataStruct psmAddrData::getData(size_t k) const{
    if (k >= arraysize) throw omnetpp::cRuntimeError("PsmAddrDataArray of size %lu indexed by %lu", (unsigned long)arraysize, (unsigned long)k);
    return this->data[k];
}

void psmAddrData::setData(size_t k, psmAddrDataStruct *data){
    // if (k >= arraysize) throw omnetpp::cRuntimeError("PsmAddrDataArray of size %lu indexed by %lu", (unsigned long)arraysize, (unsigned long)k);
    // if (this->data[k] != nullptr) throw omnetpp::cRuntimeError("PsmAddrData::setData(): a value is already set, remove it first with removeData()");
    this->data[k] = *data;
}

// void psmAddrData::removeData(size_t k){
//     if (k >= arraysize) throw omnetpp::cRuntimeError("PsmAddrDataArray of size %lu indexed by %lu", (unsigned long)arraysize, (unsigned long)k);
//     this->data[k] = nullptr;
// }

void psmAddrData::parsimPack(omnetpp::cCommBuffer *buffer) const
{
    buffer->pack(arraysize);
    for(unsigned int i = 0; i < arraysize; i++){
        this->data[i].parsimPack(buffer);
    }
}

void psmAddrData::parsimUnpack(omnetpp::cCommBuffer *buffer)
{
    buffer->unpack(arraysize);
    if (arraysize == 0) {
        this->data = nullptr;
    } else {
        this->data = new psmAddrDataStruct [arraysize];
        for(unsigned int i = 0; i < arraysize; i++){
            (this->data)[i]  = *(dynamic_cast<psmAddrDataStruct *>(buffer->unpackObject()));
        }
    }
}