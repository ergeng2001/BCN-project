/*
 * GlobalFlowId.cc
 *
 *  Created on: 2023��6��23��
 *      Author: 10202
 */
#include "GlobalFlowId.h"

namespace inet{

Define_Module(GlobalFlowId);

uint64_t GlobalFlowId::flowid = 0;

}

