/*
 * FSScheduler.cc
 *
 *  Created on:2024
 *      Author: ergeng2001
 */



#include "FSScheduler.h"

namespace inet {

Define_Module(FSScheduler);

FSScheduler::~FSScheduler()
{
    delete[] weights01;
    delete[] buckets01;
}

void FSScheduler::initialize(int stage)
{
    PacketSchedulerBase::initialize(stage);
    if (stage == INITSTAGE_LOCAL) {

        weights01 = new unsigned int[providers.size()];
        buckets01 = new unsigned int[providers.size()];

        cStringTokenizer tokenizer(par("weights01"));
        size_t i;
        for (i = 0; i < providers.size() && tokenizer.hasMoreTokens(); ++i)
             buckets01[i] = weights01[i] = utils::atoul(tokenizer.nextToken());

        if (i < providers.size())
             throw cRuntimeError("Too few values given in the weights01 parameter.");
        if (tokenizer.hasMoreTokens())
             throw cRuntimeError("Too many values given in the weights01 parameter.");

        for (auto provider : providers)
            collections.push_back(dynamic_cast<FSqueue *>(provider));

        numInputs = gateSize("in");

        cModule *radioModule = getParentModule()->getParentModule();//FSScheduler->FlowsailQueue->eth
        EV<<"parentmodule = "<<radioModule<<endl;
        radioModule->subscribe(FlowsailMac::bfcPausedFrame,this);
        radioModule->subscribe(FlowsailMac::bfcResumeFrame,this);
        for (int i = 0; i < numInputs; ++i) {
            ispaused[i] = false;
        }
    }
}

int FSScheduler::getNumPackets() const
{
    int size = 0;
    for (auto collection : collections)
        if (collection != nullptr)
            size += collection->getNumPackets();
        else
            return -1;
    return size;
}

b FSScheduler::getTotalLength() const
{
    b totalLength(0);
    for (auto collection : collections)
        if (collection != nullptr)
            totalLength += collection->getTotalLength();
        else
            return b(-1);
    return totalLength;
}

Packet *FSScheduler::getPacket(int index) const
{
    int origIndex = index;

    for (auto collection : collections) {
        auto numPackets = collection->getNumPackets();
        if (index < numPackets)
        {
            return collection->getPacket(index);
        }

        else
            index -= numPackets;
    }
    throw cRuntimeError("Index %i out of range", origIndex);
}

void FSScheduler::removePacket(Packet *packet)
{
    Enter_Method("removePacket");
    for (auto collection : collections) {
        int numPackets = collection->getNumPackets();
        for (int j = 0; j < numPackets; j++) {
            if (collection->getPacket(j) == packet) {
                collection->removePacket(packet);
                return;
            }
        }
    }
    throw cRuntimeError("Cannot find packet");
}

void FSScheduler::removeAllPackets()
{
    Enter_Method("removeAllPackets");
    for (auto collection : collections)
        collection->removeAllPackets();
}

bool FSScheduler::canPullSomePacket(cGate *gate) const
{
    for (int i = 0; i < (int)inputGates.size(); i++) {
        if (ispaused.find(i)->second) // queue id paused.
        {
            continue;
        }else{
            auto inputProvider = providers[i];
            if (inputProvider->canPullSomePacket(inputGates[i]->getPathStartGate()))
                return true;
        }
    }
    return false;
}

int FSScheduler::schedulePacket()// return Qid index//
{
        int firstWeighted = -1;
        bool notallPaused = false;
        EV<<"--------Start scheduler packet--------. simTime = "<<simTime()<<endl;
        for (size_t i = 0; i < providers.size(); ++i) {
            if (providers[i]->canPullSomePacket(inputGates[i]->getPathStartGate())) {
                if(!ispaused.find(i)->second){
                    notallPaused = true;
                    EV<<"queue_"<<i <<" not Paused."<<endl;
                    if (buckets01[i] > 0){
                        buckets01[i]--;
                        EV<<"Scheduler packet, queueid = "<<i<<", simTime = "<<simTime()<<endl;
                        return getInputGateIndex(i);
                    }else if (firstWeighted == -1 && weights01[i] > 0)
                        firstWeighted = (int)i;
                }else{
                    EV<<"queue_"<<i<<" is Paused. Continue next queue. simTime = "<<simTime()<<endl;
                    continue;
                }
            }
        }
        if(!notallPaused){
            EV<<"Clocked, All queue is Paused."<<endl;
            return -1;
        }
        if(firstWeighted != -1){
            for (size_t i = 0; i < providers.size(); ++i)
                 buckets01[i] = weights01[i];
            buckets01[firstWeighted]--;
            EV<<"Scheduler queueid = "<<firstWeighted<<", simTime = "<<simTime()<<endl;
            return getInputGateIndex(firstWeighted);
        }
        EV<<"All queue has no packets."<<endl;
        return -1;
}

Packet *FSScheduler::pullPacket(cGate *gate)//
{
    Enter_Method("pullPacket");
    checkPacketStreaming(nullptr);
    int index = callSchedulePacket();
    auto packet = providers[index]->pullPacket(inputGates[index]->getPathStartGate());//outputGate;
    take(packet);
    EV_INFO << "Scheduling Queueid " << index <<", packet =" << EV_FIELD(packet) << EV_ENDL;
    handlePacketProcessed(packet);
    emit(packetPulledSignal, packet);
    animatePullPacket(packet, outputGate);
    updateDisplayString();
    return packet;

}

void FSScheduler::receiveSignal(cComponent *source, simsignal_t signalID, cObject *obj, cObject *details)
{
    if(signalID==FlowsailMac::bfcPausedFrame||signalID==FlowsailMac::bfcResumeFrame){
        EV<<"FSScheduler::receiveSignal(), receive bfc frame"<<endl;
        processbfcframe(obj);
    }
}

//FSSchduler receive bfc "pause"/"resume" Frame.
void FSScheduler::processbfcframe(cObject *obj){
    Enter_Method("processbfcframe");
    auto pauseFrame = check_and_cast<const EthernetBfcFrame *>(obj);
    int queueid = pauseFrame->getQueueID();
    int flowid = pauseFrame->getFlowID();

    if(pauseFrame->getOpCode()==ETHERNET_BFC_PAUSE){
        ispaused[queueid] = true;
        EV<<"---------Scheduler receive Flowsail pause frame to queueid =  "<<queueid <<endl;

    }else if(pauseFrame->getOpCode()==ETHERNET_BFC_RESUME){
        ispaused[queueid] = false;
        EV<<"---------Scheduler receive Flowsail resume frame to queueid =  "<<queueid <<endl;

      }//for receive ETHERNER_BFC_RESUME.
    }//for process bfc frame.
} // namespace inet.

