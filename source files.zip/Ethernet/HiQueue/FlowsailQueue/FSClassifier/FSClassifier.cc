/*
 * FSClassifier.cc
 *
 *  Created on: 2024��6��3��
 *      Author: ergeng2001
 */



#include <iostream>
#include <stdlib.h>
#include <time.h>

#include "inet/HiNA/Ethernet/HiQueue/REDPFCQueue/REDPFCQueue.h"
#include "inet/HiNA/Ethernet/HiQueue/ABMQueue/ABMQueue.h"
#include "inet/common/ProtocolTag_m.h"
#include "inet/common/Simsignals.h"
#include "inet/linklayer/common/EtherType_m.h"
#include "inet/linklayer/common/InterfaceTag_m.h"
#include "inet/linklayer/common/MacAddressTag_m.h"
#include "inet/linklayer/ethernet/common/EthernetControlFrame_m.h"
#include "inet/linklayer/ethernet/common/EthernetMacHeader_m.h"
#include "inet/networklayer/common/NetworkInterface.h"
#include "inet/physicallayer/wired/ethernet/EthernetSignal_m.h"


#include "inet/linklayer/ethernet/base/EthernetMacBase.h"
#include "inet/HiNA/Messages/HiTag/HiTag_m.h"
#include "inet/HiNA/Messages/PfcFrame/EthernetPfcFrame_m.h"
#include "inet/HiNA/Messages/BFCHeader/BFCHeader_m.h"

#include "inet/networklayer/ipv4/Ipv4Header_m.h"
#include "inet/transportlayer/udp/UdpHeader_m.h"
#include "inet/HiNA/Messages/HPCC/INTHeader_m.h"
#include "inet/HiNA/Ethernet/HiQueue/HiScheduler/WrrScheduler.h"

#include "inet/common/packet/Packet.h"
#include "FSClassifier.h"
#include "inet/HiNA/Ethernet/HiQueue/FlowsailQueue/FSqueue/FSqueue.h"
#include "inet/HiNA/Ethernet/HiQueue/FlowsailQueue/FSScheduler/FSScheduler.h"

namespace inet {

Define_Module(FSClassifier);

simsignal_t FSClassifier::packetClassifiedSignal = cComponent::registerSignal("packetClassified");

//map_NFT FSClassifier::NFT;
//
//FSClassifier::map_CFT FSClassifier::CFT;
//
//FSClassifier::map_QT FSClassifier::QT;

void FSClassifier::initialize(int stage)
{
    PacketClassifierBase::initialize(stage);
    if (stage == INITSTAGE_LOCAL) {
    numOutGates = gateSize("out");
    std::vector<int> Nums;
    const char *prios = par("Nums");
    cStringTokenizer tokens(prios);
    while (tokens.hasMoreTokens())
    {
        int temp_nums = atoi(tokens.nextToken());
        Nums.push_back(temp_nums);
    }
        Nums_size = (int)Nums.size();

    if (Nums_size > numOutGates)
        throw cRuntimeError("%d priority values are given, but the module has only %d out gates",
                Nums_size, numOutGates);
    for (int i = 0; i < numOutGates; ++i)
    {
        numbToGateIndexMap[i] = Nums[i];
    }
    numRcvd = 0;
    WATCH(numRcvd);

    cModule *radioModule = getParentModule()->getParentModule();//FSClassifier->FlowsailQueue->eth
    EV<<"parentmodule = "<<radioModule<<endl;

    cModule *device = radioModule -> getParentModule();
    radioModule->subscribe(FlowsailMac::bfcPausedFrame,this);
    radioModule->subscribe(FlowsailMac::bfcResumeFrame,this);
    }

}

void FSClassifier::handleMessage(cMessage *msg)
{
    Enter_Method("classifiedPacket");
    Packet *packet = check_and_cast<Packet *>(msg);
    numRcvd++;
    int index = classifyPacket(packet);

    if(!strcmp(packet->getFullName(),"credit"))
    {
        EV<<"send to creditqueue"<<endl;
        send(packet, "creditOut");
    }

    else if (index >= 0){
        EV<<"send "<<packet<<" to "<<index<<". simTime = "<<simTime()<<endl;
        send(packet, "out", index);
    }
    else{
        EV<<"send to default queue"<<endl;
        send(packet, "defaultOut");
    }
    emit(packetClassifiedSignal,packet);

}

int FSClassifier::classifyPacket(Packet *packet)
{
    if (std::string(packet->getFullName()).find("Flowsail") != std::string::npos){

        //1.get packet's flowid and last
        int flowid;
        bool last;
        for(auto& region:packet->peekData()->getAllTags<HiTag>()){
            flowid = region.getTag()->getFlowId();
            last = region.getTag()->isLastPck();
        }

        //2.check rsvQ, set  queueid = 7
        int queueid;
        bool inrsvQ = false;
        if(std::find(rsvQ.begin(),rsvQ.end(),flowid) != rsvQ.end()){//find flowid in rsvQ.
            EV<<"flowid "<<flowid<<" in revQ. Set queueid = 7."<<endl;
            queueid = 7;
            inrsvQ = true;
        }

        //3.check !inrsvQ
        if((!inrsvQ) && (map_NFT.find(flowid)!=map_NFT.end())){
            queueid = map_NFT.find(flowid)->second;
            EV<<"Find flowid "<<flowid<<" in map_NFT. Set queueid = "<<queueid<<endl;
        }else if(!inrsvQ){//new flowid.
            srand( (unsigned)time( NULL ) );
            queueid = rand() %(Nums_size-1)+0;
            EV<<"flowid = "<<flowid<<"  in srand(time). Set queueid = "<<queueid <<endl;
            //save flowid in map
            map_NFT.insert(std::pair<uint32_t,uint>(flowid,queueid));
            EV<<"map_NFT insert pair<uint32_t,uint>("<<flowid<<","<<queueid<<")"<<endl;
            //print item in map_NFT
            std::map<uint32_t,uint>::iterator iter = map_NFT.begin();
            for(;iter != map_NFT.end();iter++){
                EV<<"iter->first(flowid):"<<iter->first<<",iter->second:"<<iter->second<<endl;
            }
        }

        //4.check last packet
        if(last){
            //find flowid in map_NFT
            if(map_NFT.find(flowid)!=map_NFT.end()){
                map_NFT.erase(map_NFT.find(flowid));
                EV<<"last packet is "<<last<<",map_NFT erase flowid "<<flowid<<endl;
            }else{
                EV<<"Last packet, flowid not in map_NFT. Don't need delete flowid in map_NFT."<<endl;
            }

            if(inrsvQ){
                 EV<<"last packet is "<<last<<" ,rsvQ erase flowid "<<flowid<<endl;
                 //use erase
                 for(std::vector<uint32_t>::iterator iter = rsvQ.begin(); iter != rsvQ.end(); iter++){
                     if(*iter == flowid){
                         iter = rsvQ.erase(iter);
                         iter--;
                     }
                 }
            }else{
                EV<<"Last packet, flowid not in rsvQ. Don't need delete flowid in rsvQ."<<endl;
            }
        }

        //5.set packet's BFCHeader queueid
        b offset(0);
        auto ethHeader = packet->peekDataAt<EthernetMacHeader>(offset);
        offset += ethHeader->getChunkLength();
        auto bfcHeader = packet->removeDataAt<BFCHeader>(offset);

        bfcHeader ->setQueueID(queueid);
        EV<<packet<<" flowid = "<<flowid<<", set queueid = "<<bfcHeader ->getQueueID()<<endl;
        packet->insertDataAt(bfcHeader, offset);
        return queueid;
    }//for Flowsail packet

    if (std::string(packet->getFullName()).find("arp") != std::string::npos || std::string(packet->getFullName()).find("bind") != std::string::npos)
        return -1;

    return -1;//for error!
}

void FSClassifier::refreshDisplay() const
{
    char buf[33] = "";
    if (numRcvd > 0)
        sprintf(buf + strlen(buf), "classified:%d ", numRcvd);
    getDisplayString().setTagArg("t", 0, buf);

}
//register signal
void FSClassifier::receiveSignal(cComponent *source, simsignal_t signalID, cObject *obj, cObject *details)
{
    if(signalID==FlowsailMac::bfcPausedFrame||signalID==FlowsailMac::bfcResumeFrame){
        EV<<"FSClassifier receive BFC frame."<<endl;
        auto Frame = check_and_cast<const EthernetBfcFrame *>(obj);
        int flowid = Frame->getFlowID();

        bool inrsvQ = false;
        std::vector<uint32_t>::iterator it;
        for(it=rsvQ.begin(); it!= rsvQ.end();it++){
            if(*it == flowid){
                EV<<"flowid "<<flowid<<" Frame in rsvQ. OK!"<<endl;
                inrsvQ = true;
                break;
            }
        }

        //receive "pause" frame
        if(Frame->getOpCode()==ETHERNET_BFC_PAUSE){
            EV<<"FSClassifier reveive ETHERNET_BFC_PAUSE."<<endl;
            if(!inrsvQ){
                EV<<"flowid "<<flowid<<" pause Frame not in rsvQ. Insert it!"<<endl;
                rsvQ.push_back(flowid);
            }

        }else if(Frame->getOpCode()==ETHERNET_BFC_RESUME){//receive "resume" frame
            EV<<"FSClassifier reveive ETHERNET_BFC_RESUME."<<endl;
            if(inrsvQ){
                 EV<<"flowid "<<flowid<<" resume Frame in rsvQ. Delete it!"<<endl;
                 rsvQ.erase(it);
            }
        }
    }else{
        EV<<"Error! signalID is false!"<<endl;
    }
}


}// namespace inet




