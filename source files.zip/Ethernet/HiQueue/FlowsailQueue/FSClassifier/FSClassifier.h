/*
 * FSClassifier.h
 *
 *  Created on: 2024��6��3��
 *      Author: ergeng2001
 */


#ifndef __INET_FSCLASSIFIER_H
#define __INET_FSCLASSIFIER_H

#include "inet/HiNA/Ethernet/HiEthernetMac/HiEthernetMac.h"
#include "inet/HiNA/Ethernet/FlowsailMac/FlowsailMac.h"
#include "inet/queueing/base/PacketClassifierBase.h"
#include "inet/queueing/contract/IPacketCollection.h"
#include "inet/HiNA/Messages/HiTag/HiTag_m.h"
#include "inet/common/packet/Packet.h"
#include <string.h>
#include <limits>
#include <vector>
using namespace inet::queueing;

namespace inet {


class INET_API FSClassifier : public PacketClassifierBase, public cListener
{
    public:
    //for flowsail
        //<flowid,queueid> map_NFT
        std::map<uint32_t,uint> map_NFT;

        //vector <flowid>, set flowid in queue_7
        std::vector<uint32_t>  rsvQ;

  protected:
    int numOutGates = 0;
    std::map<int, uint32_t> numbToGateIndexMap;

    int numRcvd = 0;
    int Nums_size;

    simtime_t last_flow_finishtime = 0;

    static simsignal_t packetClassifiedSignal;

    int64_t minlength = std::numeric_limits<int64_t>::max();
    int minqueueid =0;

    int64_t lastflowid = -1;
    int lastqueueid =-1;
    int tempqueueid =-1;

    virtual void initialize(int stage) override;
    virtual void handleMessage(cMessage *msg) override;
    virtual void refreshDisplay() const override;
    virtual int classifyPacket(Packet *packet) override;
    virtual void receiveSignal(cComponent *source, simsignal_t signalID, cObject *obj, cObject *details) override;
    virtual ~FSClassifier() {map_NFT.clear();rsvQ.clear();}

};

} // namespace inet

#endif







