/*
 * FSqueue.cc
 *
 *  Created on: 2024 6 3
 *      Author: ergeng2001
 */

#include "FSqueue.h"
#include "inet/common/ModuleAccess.h"
#include "inet/common/PacketEventTag.h"
#include "inet/common/Simsignals.h"
#include "inet/common/TimeTag.h"
#include "inet/queueing/function/PacketComparatorFunction.h"
#include "inet/queueing/function/PacketDropperFunction.h"
#include "inet/common/packet/chunk/Chunk.h"
#include "inet/common/packet/Packet.h"

#include <vector>
#include <algorithm>
#include <math.h>

#include "inet/networklayer/common/NetworkInterface.h"

#include "inet/linklayer/base/MacProtocolBase.h"
#include <algorithm>
#include "inet/HiNA/Messages/BFCHeader/BFCHeader_m.h"
#include "inet/HiNA/Messages/BFCHeader/BFCHeaderSerializer.h"
#include "inet/HiNA/Messages/BFCTag/isPause_m.h"

#include "inet/networklayer/common/NetworkInterface.h"
#include "inet/networklayer/ipv4/Ipv4Header_m.h"



namespace inet {

Define_Module(FSqueue);

simsignal_t FSqueue::bfcPausedSignal =
        cComponent::registerSignal("bfcPaused");
simsignal_t FSqueue::bfcResumeSignal =
        cComponent::registerSignal("bfcResume");

simsignal_t FSqueue::bfcDecelerationSignal =
        cComponent::registerSignal("bfcDeceleration");
simsignal_t FSqueue::bfcSpeedupSignal =
        cComponent::registerSignal("bfcSpeedup");

b FSqueue::sharedBuffer[100][100]={};


void FSqueue::initialize(int stage)
{
    PacketQueueBase::initialize(stage);
    if (stage == INITSTAGE_LOCAL) {
        WATCH(sendcnpdel);
        WATCH(sendcnpspe);

        radioModule = getParentModule()->getParentModule(); //FSqueue -> FSQueue -> eth
        eth_Interface = check_and_cast<NetworkInterface*>(radioModule);
        queue.setName("storage");
        producer = findConnectedModule<IActivePacketSource>(inputGate);
        collector = findConnectedModule<IActivePacketSink>(outputGate);
        packetCapacity = par("packetCapacity");
        EV<<"packetCapacity = "<<packetCapacity  <<endl;//4000
        dataCapacity = b(par("dataCapacity"));
        EV<<"dataCapacity = "<<dataCapacity <<endl;//50MB
        switchid=findContainingNode(this)->getId();EV<<"switchid = "<<switchid<<endl;
        numb = par("numb");
        sharedBuffer[switchid][numb] = b(par("sharedBuffer"));
        EV<<"sharedBuffer[switchid][numb] = "<<sharedBuffer[switchid][numb] <<endl;//1.5MB
        headroom = b(par("headroom"));//179200b == 22400B
        EV<<"headroom ="<<headroom <<endl;
        useBfc = par("useBfc");
        EV<<"useBfc = "<<useBfc<<endl;
        XON = par("XON");
        EV<<"XON = "<<XON<<endl;
        XOFF = par("XOFF");
        EV<<"XOFF = "<<XOFF<<endl;
        Kmax=par("Kmax");
        Kmin=par("Kmin");
        Pmax=par("Pmax");
        useEcn=par("useEcn");
        alpha=par("alpha");
        //for sharedBuffer
        queuelengthVector.setName("queuelength (bit)");
        sharedBufferVector.setName("sharedbuffer (bit)");
        //for sharedBuffer
        count = -1;
        packetComparatorFunction = createComparatorFunction(par("comparatorClass"));
        if (packetComparatorFunction != nullptr)
            queue.setup(packetComparatorFunction);
        packetDropperFunction = createDropperFunction(par("dropperClass"));
    }
    else if (stage == INITSTAGE_QUEUEING) {
        checkPacketOperationSupport(inputGate);
        checkPacketOperationSupport(outputGate);
        if (producer != nullptr)
            producer->handleCanPushPacketChanged(inputGate->getPathStartGate());
    }
    else if (stage == INITSTAGE_LAST)
        updateDisplayString();
}

IPacketDropperFunction *FSqueue::createDropperFunction(const char *dropperClass) const
{
    if (strlen(dropperClass) == 0)
        return nullptr;
    else
        return check_and_cast<IPacketDropperFunction *>(createOne(dropperClass));
}

IPacketComparatorFunction *FSqueue::createComparatorFunction(const char *comparatorClass) const
{
    if (strlen(comparatorClass) == 0)
        return nullptr;
    else
        return check_and_cast<IPacketComparatorFunction *>(createOne(comparatorClass));
}

bool FSqueue::isOverloaded() const
{
    return (packetCapacity != -1 && getNumPackets() > packetCapacity) ||
           (dataCapacity != b(-1) && getTotalLength() > dataCapacity);
}

int FSqueue::getNumPackets() const
{
    return queue.getLength();
}

Packet *FSqueue::getPacket(int index) const
{
    if (index < 0 || index >= queue.getLength())
        throw cRuntimeError("index %i out of range", index);
    return check_and_cast<Packet *>(queue.get(index));
}

void FSqueue::handleMessage(cMessage *message)
{
    auto packet = check_and_cast<Packet *>(message);
    if(BufferManagement(message))
    {
        pushPacket(packet, packet->getArrivalGate());
    }
    else{
        dropPacket(packet, QUEUE_OVERFLOW);
    }
}

void FSqueue::pushPacket(Packet *packet, cGate *gate)
{

    Enter_Method("pushPacket");
    take(packet);
    cNamedObject packetPushStartedDetails("atomicOperationStarted");
    emit(packetPushStartedSignal, packet, &packetPushStartedDetails);
    EV_INFO << "Pushing packet" << EV_FIELD(packet) <<" ,simTime = "<<simTime()<< EV_ENDL;
    queue.insert(packet);

    int iface = packet->addTagIfAbsent<InterfaceInd>()->getInterfaceId(); //iface is the packet form port;not the now port;
    if (std::string(packet->getFullName()).find("Flowsail") != std::string::npos){//  arp

    if(useBfc){
        //1.get packet queueid and upstreamQueueID
        b offset(0);
        auto ethHeader = packet->peekDataAt<EthernetMacHeader>(offset);
        offset += ethHeader->getChunkLength();
        auto bfcHeader = packet->peekDataAt<BFCHeader>(offset);
        int queueid = bfcHeader->getQueueID();
        int upstreamQueueID = bfcHeader->getUpstreamQueueID();

        //2.get flowID
        int flowid;
        for(auto& region:packet->peekData()->getAllTags<HiTag>()){
            flowid = region.getTag()->getFlowId();
        }

        //3.check flowid in map_flowinfo
        if(map_flowinfo.find(flowid) != map_flowinfo.end()){//flowid in map_flowinfo
            map_flowinfo.find(flowid)->second.stor_pcksize += packet->getBitLength();
            int64_t flow_size =  map_flowinfo.find(flowid)->second.stor_pcksize;
            EV<<"flowid "<<flowid<<" in map_flowinfo, save stor_size = "<<flow_size<<endl;
        }else{//add <flowid,flowinfo> //add <flowid> QT
            flowinfo new_flowinfo;
            new_flowinfo.stor_pcksize = packet->getBitLength();
            new_flowinfo.pauseNum = 0;
            map_flowinfo.insert(std::pair<uint32_t,flowinfo>(flowid,new_flowinfo));
            QT.push_back(flowid);
            //print flowid in QT
            EV<<"QT have flowid: "<<endl;
            for(std::vector<uint32_t>::iterator iter_QT = QT.begin(); iter_QT != QT.end(); ){
                    EV<< *iter_QT <<endl;
                    iter_QT++;
            }

            EV<<"flowid "<<flowid<<" not in map_flowinfo, insert it!"<<endl;
        }

        //4.queuelength > XOFF || Sfair
        EV<<"queue XOFF = "<<XOFF <<", queue XON = "<<XON <<endl;
        if((XOFF != -1) && (queue.getByteLength()>=XOFF||(queue.getBitLength()>dataCapacity.get()&&sharedBuffer[switchid][numb]<headroom))){
            EV<<"###########When push packet, queueleng "<<queue.getByteLength()<<" > "<< XOFF <<" ############"<<endl;
            //set packet isPause
            auto PauseTag = packet -> addTag<isPause>();
            PauseTag->setBfcisPause(true);

            //flowinfo.paiseNum++;
            ++map_flowinfo.find(flowid)->second.pauseNum;
            EV<<"flowid "<<flowid<<" in map_flowinfo, pauseNum = "<<map_flowinfo.find(flowid)->second.pauseNum<<endl;
        }else if(XOFF != -1 && queue.getByteLength()< XOFF && queue.getByteLength()>= XON){
            EV<<"###########When push packet, XON "<<"< "<<queue.getByteLength()<< " < "<< XOFF <<" ############"<<endl;
            uint32_t QT_flowNum = QT.size();
            //compute Sfair
            uint64_t Sfair = queue.getBitLength() >> int(std::ceil(log2(QT_flowNum)));
            EV<<"queueid = "<<queueid <<endl;
            EV<<"QT_flowNum = "<< QT_flowNum <<endl;
            EV<<"log2(QT_flowNum) = "<<log2(QT_flowNum) <<endl;
            EV<<"int(std::ceil(log2(QT_flowNum))) = "<<int(std::ceil(log2(QT_flowNum))) <<endl;
            EV<<"queue.getBitLength() = "<<queue.getBitLength() <<endl;//队列值是12208
            EV<<"Sfair = "<<Sfair <<endl;//Sfair的计算值是12208

            int64_t flow_size =  map_flowinfo.find(flowid)->second.stor_pcksize;
            if(flow_size > Sfair){
                EV<<"###########When push packet, flowid "<<flowid<<" ,flow_size "<<flow_size<<" > "<<Sfair<<" ############"<<endl;
                //set packet isPause
                auto PauseTag = packet -> addTag<isPause>();
                PauseTag->setBfcisPause(true);

                //flowinfo.paiseNum++;
                ++map_flowinfo.find(flowid)->second.pauseNum;
                EV<<"flowid "<<flowid<<" in map_flowinfo, pauseNum = "<<map_flowinfo.find(flowid)->second.pauseNum<<endl;
            }else{
                EV<<"flowid "<<flowid<<" ,flow_size "<<flow_size<<" <= "<<Sfair<<endl;
            }
        }else{
            EV<<"###########When push packet, "<<queue.getByteLength()<< " < XON "<< XON <<" ############"<<endl;
        }

        EV<<"When push packet, map_flowinfo find flowid "<<flowid<<", pauseNum = "<<map_flowinfo.find(flowid)->second.pauseNum<<endl;

        //5.check isPause packet,send "pause" signal.
        //find isPause
        auto pisPaused = packet ->findTag<isPause>();
        if(pisPaused != nullptr){
        if(pisPaused->getBfcisPause()){
        if(map_flowinfo.find(flowid)->second.pauseNum == 1){
            auto pck = new Packet("pause");
            auto newtag=pck->addTagIfAbsent<HiTag>();
            newtag->setOp(ETHERNET_BFC_PAUSE);
            newtag->setQueueID(upstreamQueueID);//for flowsail;
            newtag->setFlowId(flowid); //for flowsail;
            newtag->setInterfaceId(iface);
            EV<<"Send Flowsail bfcPausedSignal, eth = "<<iface<<", upstreamQid = "<<upstreamQueueID << ", flowid = " << flowid <<endl;
            emit(bfcPausedSignal,pck);
            delete pck;
         }
        }}
        }//for useBFC
    }//for Flowsail
    if (collector != nullptr && getNumPackets() != 0)
        collector->handleCanPullPacketChanged(outputGate->getPathEndGate());
    cNamedObject packetPushEndedDetails("atomicOperationEnded");
    emit(packetPushEndedSignal, nullptr, &packetPushEndedDetails);
    updateDisplayString();
}

Packet *FSqueue::pullPacket(cGate *gate)
{
    Enter_Method("pullPacket");
    auto packet = check_and_cast<Packet *>(queue.front());
    int iface = packet->addTagIfAbsent<InterfaceInd>()->getInterfaceId();

    if (std::string(packet->getFullName()).find("Flowsail") != std::string::npos){
        b offset(0);
        b offset2(0);
        //1.get queueid and upstreamQueueID
        auto ethHeader = packet->peekDataAt<EthernetMacHeader>(offset);
        offset += ethHeader->getChunkLength();// for get BFCHeader
        offset2 += ethHeader->getChunkLength();// for replace BFCHeader
        auto bfcHeader = packet->peekDataAt<BFCHeader>(offset);
        int upstreamQueueID = bfcHeader->getUpstreamQueueID();
        int queueid = bfcHeader->getQueueID();

        //2.get flowID and last
        uint32_t flowid;
        bool last = false;
        for (auto& region : packet->peekData()->getAllTags<HiTag>()){
            flowid = region.getTag()->getFlowId();
            last = region.getTag()->isLastPck();
        }

        //3.check flowid in map_flowinfo
        if(map_flowinfo.find(flowid) != map_flowinfo.end()){
            map_flowinfo.find(flowid)->second.stor_pcksize -= packet->getBitLength();
            int64_t flow_size =  map_flowinfo.find(flowid)->second.stor_pcksize;
            EV<<"pull packet in flowid "<<flowid<<" in map_flowinfo, remain stor_size = "<<flow_size<<endl;

            //5.find isPause
            auto pisPaused = packet ->findTag<isPause>();
            if(pisPaused != nullptr){
            if(pisPaused->getBfcisPause()){
                --map_flowinfo.find(flowid)->second.pauseNum;//before flow's last packet is delete.
                EV<<"Pull isPause packet, find flowid "<<flowid<<", pauseNum = "<<map_flowinfo.find(flowid)->second.pauseNum<<endl;
                //6.pauseNum == 0; send "resume" frame
                if(map_flowinfo.find(flowid)->second.pauseNum == 0){
                    auto pck = new Packet("resume");
                    auto newtag=pck->addTagIfAbsent<HiTag>();
                    newtag->setOp(ETHERNET_BFC_RESUME);
                    newtag->setQueueID(upstreamQueueID);
                    newtag->setFlowId(flowid);
                    newtag->setInterfaceId(iface);
                    EV<<"Send Flowsail bfcResumeSignal, eth = "<<iface<<", upstreamQid = "<<upstreamQueueID << ", flowid = " << flowid <<endl;
                    emit(bfcResumeSignal,pck);
                    delete pck;
                  }
               }
            }

            //4. flow_size == 0
            if(last){
                map_flowinfo.erase(map_flowinfo.find(flowid));
                EV<<packet<<" is last"<<",map_flowinfo erase flowid "<<flowid<<endl;
                //use erase flowid
                for(std::vector<uint32_t>::iterator iter_QT = QT.begin(); iter_QT != QT.end(); ){
                    if(*iter_QT == flowid){
                        iter_QT = QT.erase(iter_QT);
                        EV<<"QT erase flowid "<<flowid <<endl;
                    }else{
                        iter_QT++;
                    }
                }
            }

        }else{
            EV<<"This is Module "<< radioModule->getParentModule()<<endl;
            EV<<"Pull "<<packet<<" flowid "<<flowid <<" not in map_flowinfo!"<<endl;
        }

        //7.change upstreamQueueID = queueid
        auto remove_bfcHeader = packet->removeDataAt<BFCHeader>(offset2);
        remove_bfcHeader->setUpstreamQueueID(queueid);
        packet->insertDataAt(remove_bfcHeader,offset2);
        EV<<"pull packt!  Reset packet's upstreamQid = queueid"<<" : "<<queueid<<endl;
    }//for flowsail

    EV_INFO << "Pulling packet" << EV_FIELD(packet) << EV_ENDL;
    EV<<"queuelength = "<<queue.getBitLength()<<"b"<<endl;
    if(queue.getBitLength()-dataCapacity.get()>=packet->getBitLength()){
        sharedBuffer[switchid][numb]+=b(packet->getBitLength());
    }else if(queue.getBitLength()>=dataCapacity.get()){
        sharedBuffer[switchid][numb]+=b(queue.getBitLength()-dataCapacity.get());
    }
    queue.pop();
    EV<<"after pop queuelength = "<<queue.getBitLength()<<endl;
    auto queueingTime = simTime() - packet->getArrivalTime();
    auto packetEvent = new PacketQueuedEvent();
    packetEvent->setQueuePacketLength(getNumPackets());
    packetEvent->setQueueDataLength(getTotalLength());
    insertPacketEvent(this, packet, PEK_QUEUED, queueingTime, packetEvent);
    increaseTimeTag<QueueingTimeTag>(packet, queueingTime, queueingTime);
    emit(packetPulledSignal, packet);

    lastResult = doRandomEarlyDetection(packet);
    switch (lastResult) {
    case RANDOMLY_ABOVE_LIMIT:
    case ABOVE_MAX_LIMIT: {
        if (useEcn) {
            //for BFCHeader. Because packet has add BFCHeader after ethernet.
            /*
            auto ethHeader = packet->popAtFront<EthernetMacHeader>();
            auto bfcHeader = packet->popAtFront<BFCHeader>();
            EV<<packet->getFullName()<<" >ECN, packet remove BFCHeader."<<endl;
            */
            IpEcnCode ecn = EcnMarker::getEcn(packet);
            EV<<packet->getFullName()<<" >ECN, packet reset ECN."<<endl;
            EV<<"ecn = "<<ecn<<endl;
            if (ecn != IP_ECN_NOT_ECT) {
                // if next packet should be marked and it is not
                if (markNext && ecn != IP_ECN_CE) {
                    EV<<"set ECN, markNext = false;"<<endl;
                    EcnMarker::setEcn(packet, IP_ECN_CE);
                    markNext = false;
                }
                else {
                    if (ecn == IP_ECN_CE)
                        markNext = true;
                    else{
                        EV<<"set ECN"<<endl;
                        EcnMarker::setEcn(packet, IP_ECN_CE);
                    }
                }
            }
        }
    }
    case RANDOMLY_BELOW_LIMIT:
    case BELOW_MIN_LIMIT:
        break;
    default:
        throw cRuntimeError("Unknown RED result");
    }
    animatePullPacket(packet, outputGate);
    updateDisplayString();
    return packet;
}

FSqueue::RedResult FSqueue::doRandomEarlyDetection(const Packet *packet)
{
    int64_t queueLength = queue.getByteLength();
    if (Kmin <= queueLength && queueLength < Kmax) {
        count++;
        const double pb = Pmax * (queueLength - Kmin) / (Kmax - Kmin);
        if (dblrand() < pb) {EV<<"RANDOMLY ABOVE LIMIT"<<endl;
            count = 0;
            return RANDOMLY_ABOVE_LIMIT;
        }
        else{EV<<"RANDOMLY BELOW LIMIT"<<endl;
            return RANDOMLY_BELOW_LIMIT;
        }
    }
    else if (queueLength >= Kmax) {EV<<"ABOVE MAX LIMIT"<<endl;
        count = 0;
        return ABOVE_MAX_LIMIT;
    }
    else {
        count = -1;
    }
    EV<<"BELOW MIN LIMIT"<<endl;
    return BELOW_MIN_LIMIT;
}

void FSqueue::removePacket(Packet *packet)
{
    Enter_Method("removePacket");
    EV_INFO << "Removing packet" << EV_FIELD(packet) << EV_ENDL;
    queue.remove(packet);
    emit(packetRemovedSignal, packet);
    updateDisplayString();
}

void FSqueue::removeAllPackets()
{
    Enter_Method("removeAllPackets");
    EV_INFO << "Removing all packets" << EV_ENDL;
    std::vector<Packet *> packets;
    for (int i = 0; i < getNumPackets(); i++)
        packets.push_back(check_and_cast<Packet *>(queue.pop()));
    for (auto packet : packets) {
        emit(packetRemovedSignal, packet);
        delete packet;
    }
    updateDisplayString();
}

bool FSqueue::canPushSomePacket(cGate *gate) const
{
    if (packetDropperFunction)
        return true;
    if (getMaxNumPackets() != -1 && getNumPackets() >= getMaxNumPackets())
        return false;
    if (getMaxTotalLength() != b(-1) && getTotalLength() >= getMaxTotalLength())
        return false;
    return true;
}

bool FSqueue::canPushPacket(Packet *packet, cGate *gate) const
{
    if (packetDropperFunction)
        return true;
    if (getMaxNumPackets() != -1 && getNumPackets() >= getMaxNumPackets())
        return false;
    if (getMaxTotalLength() != b(-1) && getMaxTotalLength() - getTotalLength() < packet->getDataLength())
        return false;
    return true;
}

void FSqueue::handlePacketRemoved(Packet *packet)
{
    Enter_Method("handlePacketRemoved");
    if (queue.contains(packet)) {
        EV_INFO << "Removing packet" << EV_FIELD(packet) << EV_ENDL;
        queue.remove(packet);
        emit(packetRemovedSignal, packet);
        updateDisplayString();
    }
}

bool FSqueue::BufferManagement(cMessage *msg){

    Packet *packet = check_and_cast<Packet*>(msg);
    int64_t queueLength = queue.getBitLength();
    queuelengthVector.recordWithTimestamp(simTime(), queueLength);
    if(!isOverloaded())
    {
        return true;
    }

    b RemainingBufferSize = sharedBuffer[switchid][numb];
    sharedBufferVector.recordWithTimestamp(simTime(), RemainingBufferSize.get());
    EV << "currentqueuelength = " << queueLength << "b, RemainingBufferSize  = " << RemainingBufferSize.get() << "b, Packet Length is" << packet->getByteLength() <<"B"<<endl;

    maxSize = double(alpha*RemainingBufferSize.get()) ;
    if (queueLength + packet->getBitLength() >  maxSize){
        EV << "it's false" <<endl;
        //std::cout<<"queuelength > "<<maxSize<<endl;
        return false; // drop
    }
    else{
        sharedBuffer[switchid][numb] = RemainingBufferSize - b(packet->getBitLength());
        return true;
    }
}

void FSqueue::finish(){
    recordScalar("send Flowsail cnp deleration",sendcnpdel);
    recordScalar("send Flowsail cnp speedup",sendcnpspe);

}


} // namespace inet



