//
// Copyright (C) 2020 OpenSim Ltd.
//
// SPDX-License-Identifier: LGPL-3.0-or-later
//


#include "BFCScheduler.h"

namespace inet {

Define_Module(BFCScheduler);

BFCScheduler::~BFCScheduler()
{
    delete[] weights01;
    delete[] buckets01;
}

void BFCScheduler::initialize(int stage)
{
    PacketSchedulerBase::initialize(stage);
    if (stage == INITSTAGE_LOCAL) {

        weights01 = new unsigned int[providers.size()];
        buckets01 = new unsigned int[providers.size()];

        cStringTokenizer tokenizer(par("weights01"));
        size_t i;
        for (i = 0; i < providers.size() && tokenizer.hasMoreTokens(); ++i)
             buckets01[i] = weights01[i] = utils::atoul(tokenizer.nextToken());

        if (i < providers.size())
             throw cRuntimeError("Too few values given in the weights01 parameter.");
        if (tokenizer.hasMoreTokens())
             throw cRuntimeError("Too many values given in the weights01 parameter.");

        for (auto provider : providers)
            collections.push_back(dynamic_cast<BFCqueue *>(provider));

        numInputs = gateSize("in");

        cModule *radioModule = getParentModule()->getParentModule();EV<<"parentmodule = "<<radioModule<<endl;
        radioModule->subscribe(BFCMac::bfcPausedFrame,this);
        radioModule->subscribe(BFCMac::bfcResumeFrame,this);
        for (int i = 0; i < numInputs; ++i) {
            ispaused[i] = 0;
        }
    }
}

int BFCScheduler::getNumPackets() const
{
    int size = 0;
    for (auto collection : collections)
        if (collection != nullptr)
            size += collection->getNumPackets();
        else
            return -1;
    return size;
}

b BFCScheduler::getTotalLength() const
{
    b totalLength(0);
    for (auto collection : collections)
        if (collection != nullptr)
            totalLength += collection->getTotalLength();
        else
            return b(-1);
    return totalLength;
}

Packet *BFCScheduler::getPacket(int index) const //�����ǵõ�ָ��index�İ�������ָ��index�Ķ���
{
    int origIndex = index;

    for (auto collection : collections) {
        auto numPackets = collection->getNumPackets();
        if (index < numPackets)
        {
            return collection->getPacket(index);
        }

        else
            index -= numPackets;
    }
    throw cRuntimeError("Index %i out of range", origIndex);
}

void BFCScheduler::removePacket(Packet *packet)
{
    Enter_Method("removePacket");
    for (auto collection : collections) {
        int numPackets = collection->getNumPackets();
        for (int j = 0; j < numPackets; j++) {
            if (collection->getPacket(j) == packet) {
                collection->removePacket(packet);
                return;
            }
        }
    }
    throw cRuntimeError("Cannot find packet");
}

void BFCScheduler::removeAllPackets()
{
    Enter_Method("removeAllPackets");
    for (auto collection : collections)
        collection->removeAllPackets();
}

bool BFCScheduler::canPullSomePacket(cGate *gate) const
{
    for (int i = 0; i < (int)inputGates.size(); i++) {
        if (ispaused.find(i)->second != 0) // is paused
        {
            continue;
        }else{
            auto inputProvider = providers[i];
            if (inputProvider->canPullSomePacket(inputGates[i]->getPathStartGate()))
                return true;
        }
    }
    return false;
}


int BFCScheduler::schedulePacket()// return Qid index
{
    //    ��Ȩ��ѯ����
    //    1��������������һ��weight != 0�Ķ��У���һ��weight = 0�Ķ��С�
    //    2����ѯ���ж��С����ն�����Ž�����ѯ��
    //        ��Ϊÿ�����и���Ȩ��ֵ����ǰ�Ǹ���ÿ������ȨֵΪ1����ÿ�ν���һ��������ȡ��һ�����ݰ���
    //        �ڼ����е�bucketsֵ�������>0��˵����ǰ���л����Լ���ȡ��packet��bucketsֵ���ڱ�ʾ�ڲ�������������£�һ�ο��Դ�ͬһ��������ȡ�����ٸ�packet��
    //        ��ֱ��buckets = 0��˵����ǰ���в�����ȡ��packet;
    //        �����firstWeight = -1����weights >0����firstWeighted = i (i��ʾ��ǰbuckets = 0�Ķ���)
    //        �����firstNonWeight = -1,��weights =0����firstNonWeighted = i

    //    3��0 1 2���м�Ȩ����һ�ֵĵ���˳��Ϊ 0 1 1 2 2 2
    //    4��0 0 0���У����ÿ�δӶ���0������i���ȣ�0����ȫ��������󣬿�ʼ1���н����󣬿�ʼ2����....
        int firstWeighted = -1;
        bool notallPaused = false;
        EV<<"-----------Start scheduler packet. simTime = "<<simTime()<<endl;
        for (size_t i = 0; i < providers.size(); ++i) {
            if (providers[i]->canPullSomePacket(inputGates[i]->getPathStartGate())) { //���ض��к�//����������ж϶������Ƿ��а���
                //���ж϶����Ƿ���ͣ��
                if(!ispaused.find(i)->second){
                    notallPaused = true;
                    EV<<"queue_"<<i <<" not Paused."<<endl;
                    if (buckets01[i] > 0){
                        buckets01[i]--;
                        EV<<"Scheduler packet, queueid = "<<i<<", simTime = "<<simTime()<<endl;
                        return getInputGateIndex(i);
                    }else if (firstWeighted == -1 && weights01[i] > 0)
                        firstWeighted = (int)i;
                }else{
                    EV<<"queue_"<<i<<" is Paused. Continue next queue. simTime = "<<simTime()<<endl;
                    continue;
                }
            }
        }
        if(!notallPaused){
            EV<<"Clocked, All queue is Paused."<<endl;
            return -1;
        }
        if(firstWeighted != -1){
            for (size_t i = 0; i < providers.size(); ++i)
                 buckets01[i] = weights01[i];
            buckets01[firstWeighted]--;
            EV<<"Scheduler queueid = "<<firstWeighted<<", simTime = "<<simTime()<<endl;
            return getInputGateIndex(firstWeighted);
        }
        EV<<"All queue has no packets."<<endl;
        return -1;

}


Packet *BFCScheduler::pullPacket(cGate *gate)//
{
    Enter_Method("pullPacket");
    checkPacketStreaming(nullptr);
    //ÿ����ѯ����
    int index = callSchedulePacket();
    auto packet = providers[index]->pullPacket(inputGates[index]->getPathStartGate());//outputGate;
    take(packet);
    EV_INFO << "Scheduling Queueid " << index <<", packet =" << EV_FIELD(packet) << EV_ENDL;
    handlePacketProcessed(packet);
    emit(packetPulledSignal, packet);
    animatePullPacket(packet, outputGate);
    updateDisplayString();
    return packet;

}


void BFCScheduler::receiveSignal(cComponent *source, simsignal_t signalID, cObject *obj, cObject *details)
{
    if(signalID==BFCMac::bfcPausedFrame||signalID==BFCMac::bfcResumeFrame){
        EV<<"BFCScheduler::receiveSignal(), receive bfc frame"<<endl;
        processbfcframe(obj);
    }
}

void BFCScheduler::processbfcframe(cObject *obj){
    Enter_Method("processbfcframe");
    auto pauseFrame = check_and_cast<const EthernetBfcFrame *>(obj);
    if(pauseFrame->getOpCode()==ETHERNET_BFC_PAUSE){
        ispaused[pauseFrame->getQueueID()]++;

        EV<<"---------Scheduler receive the pause frame to queueID =  "<<pauseFrame->getQueueID()<<" paused"<<endl;

    }else if(pauseFrame->getOpCode()==ETHERNET_BFC_RESUME){
        ispaused[pauseFrame->getQueueID()]--;
        EV<<"----------------Scheduler receive the resume frame  to queueID =  "<<pauseFrame->getQueueID()<<" resumed"<<endl;

    }
}
} // namespace inet

