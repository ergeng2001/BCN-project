/*
 * AFCscheduler.h
 *
 *  Created on: 2023��9��12��
 *      Author: ergeng2001
 */




#ifndef INET_HINA_ETHERNET_HIQUEUE_ADAPTFCQUEUE_ADAPTFCSCHEDULER_AFCSCHEDULER_H_
#define INET_HINA_ETHERNET_HIQUEUE_ADAPTFCQUEUE_ADAPTFCSCHEDULER_AFCSCHEDULER_H_

#include "../../../AdaptFCMac/AFCMac.h"
#include "../AdaptFCqueue/AdaptFCqueue.h"
#include "inet/queueing/base/PacketSchedulerBase.h"
#include "inet/queueing/contract/IPacketCollection.h"


namespace inet {
using namespace inet::queueing;

class INET_API AFCScheduler : public PacketSchedulerBase, public virtual IPacketCollection, public cListener
{
  protected:
    unsigned int *weights = nullptr; // array of weights (has numInputs elements)
    unsigned int *buckets = nullptr; // array of tokens in buckets (has numInputs elements)

    std::vector<AdaptFCqueue *> collections;

    std::map<int,bool> ispaused;
    int numInputs;

  protected:
    virtual void initialize(int stage) override;
    virtual int schedulePacket() override;
    virtual void receiveSignal(cComponent *source, simsignal_t signalID, cObject *obj, cObject *details) override;
    void processpfcframe(cObject *obj);

  public:

    virtual ~AFCScheduler();

    virtual int getMaxNumPackets() const override { return -1; }
    virtual int getNumPackets() const override;

    virtual b getMaxTotalLength() const override { return b(-1); }
    virtual b getTotalLength() const override;

    virtual bool isEmpty() const override { return getNumPackets() == 0; }
    virtual Packet *getPacket(int index) const override;
    virtual void removePacket(Packet *packet) override;
    virtual void removeAllPackets() override;
//    virtual bool canPullSomePacket(cGate *gate) const override;
};

} // namespace inet

#endif


